/*
; #######################################################################
; # 																	#
; # Copyright(C) 2018  Toshiba Carrier (Thailand) Co, Ltd.				#
; # All Rights Reserved.												#
; # 																	#
; # The information contained herein is confidential property of		#
; # Toshiba Carrier Corporation. The user, copying, transfer or 		#
; # disclosure of such information is prohibited except by express		#
; # written agreement with Toshiba Carrier (Thailand). 					#
; # 																	#
; # <Module name>														#
; # usart0_driver.c													    #
; # 																	#
; # <Module Description>												#
; # USART 0 driver module.							     			    #
; # 																	#
; # <History>															#
; # 2018-12-17	Initial release. 										#
; # 																	#
; #######################################################################
*/

#define USART0_DRIVER_C

/************************************************************************
;* Include Section
;************************************************************************/
#include <avr/interrupt.h>
#include "GLOBAL.H"

/************************************************************************
;* Defines Section
;************************************************************************/
#define ENA_UDRE_INTR() (UCSR0B |= (1 << UDRIE0))                       // Enable Data Register Empty Interrupt                
#define DIS_UDRE_INTR() (UCSR0B &= ~(1 << UDRIE0))                      // Disable Data Register Empty Interrupt 

/************************************************************************
;* Variable Section
;************************************************************************/
static UC          USART0_rxbuf[USART0_RX_BUFFER_SIZE];
static volatile UC USART0_rx_head;
static volatile UC USART0_rx_tail;
static volatile UC USART0_rx_elements;
static UC          USART0_txbuf[USART0_TX_BUFFER_SIZE];
static volatile UC USART0_tx_head;
static volatile UC USART0_tx_tail;
static volatile UC USART0_tx_elements;

/************************************************************************
;* Function Prototype Section
;************************************************************************/

/************************************************************************
;* Module name	;USART0_init	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;Initialize USART_0 interface				
;* Details		;Baud rate = 4800, Data bit = 8, Parity = None, Stop Bits = 1						
;* Input		;Baudrate data														
;* Output		;None														
;* History		;(2018/12/17) 	;first written		;by S.Pairot		
;************************************************************************/
void USART0_init(US L_BaudRate) {                                       //
                                                                        //
  PRR &= ~(1 << PRUSART0);                                              // Enable USART0 
                                                                        //
  UBRR0H = (UC)(L_BaudRate >> 8);                                       // Baud Rate register setting 
  UBRR0L = (UC)L_BaudRate;                                              //
                                                                        //
  UCSR0A = 0 << U2X0                                                    // Double the USART transmission speed: disable
	         | 0 << MPCM0;                                              // Multi-processor Communication Mode: disabled
                                                                        //
  UCSR0B = 1 << RXCIE0                                                  // RX Complete Interrupt Enable
	         | 0 << UDRIE0                                              // USART Data Register Empty Interupt Enable: disabled
	         | 1 << RXEN0                                               // Receiver: Enable
	         | 1 << TXEN0                                               // Transmitter: Enable
	         | 0 << UCSZ02;                                             //
                                                                        // Default-->
  // UCSR0C = (0 << UMSEL01) | (0 << UMSEL00)                           // USART Asynchronous 
  //		 | (0 << UPM01) | (0 << UPM00)                              // USART Parity Mode: Disabled
  //		 | 0 << USBS0                                               // USART Stop Bit Select: 1-bit 
  //		 | (1 << UCSZ01) | (1 << UCSZ00);                           // 8-bit (default)
                                                                        //
  USART0_rx_tail     = 0;                                               // Initial variable
  USART0_rx_head     = 0;                                               //
  USART0_rx_elements = 0;                                               //                      
  USART0_tx_tail     = 0;                                               //
  USART0_tx_head     = 0;                                               //
  USART0_tx_elements = 0;                                               //
                                                                        //
}

/************************************************************************
;* Module name	;USART0_ReadChr	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;Read one character from USART_0				
;* Details		;Function will block if a character is not available.						
;* Input		;None														
;* Output		;Data read from the USART_0 module														
;* History		;(2018/12/17) 	;first written		;by S.Pairot		
;************************************************************************/
UC USART0_ReadChr(void) {                                               //
  UC L_tmptail = 0;                                                     //
                                                                        //
  if (USART0_rx_elements != 0) {                                        // Check incoming data
    L_tmptail = (USART0_rx_tail + 1) % USART0_RX_BUFFER_SIZE;           // Calculate buffer index (use Circular/Ring buffer method)
    USART0_rx_tail = L_tmptail;                                         // Store new index
    USART0_rx_elements--;                                               // Decrement elements
  }                                                                     //
	                                                                    //
  return (USART0_rxbuf[L_tmptail]);                                     // Return data
}

/************************************************************************
;* Module name	;USART0_WriteChr	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;Write one character to USART_0			
;* Details		;Function will block until a character can be accepted.						
;* Input		;Data The character to write to the USART														
;* Output		;None														
;* History		;(2018/12/17) 	;first written		;by S.Pairot		
;************************************************************************/
void USART0_WriteChr(const UC L_data) {                                 //
  UC L_tmphead;														    //
                                                                        //
  L_tmphead = (USART0_tx_head + 1) % USART0_TX_BUFFER_SIZE;             // Calculate buffer index
                                                                        //
  if (USART0_tx_elements != USART0_TX_BUFFER_SIZE) {                    // Wait for free space in buffer
    USART0_txbuf[L_tmphead] = L_data;                                   // Store data in buffer
	USART0_tx_head = L_tmphead;                                         // Store new index
    USART0_tx_elements++;                                               // Increment elements
                                                                        //
    ENA_UDRE_INTR();                                                    // Enable Data Register Empty Interrupt 
  }                                                                     //
}                                                                       //

/************************************************************************
;* Module name	;USART0_IsRxReady	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;Check USART_0 is ready to read			
;* Details		;						
;* Input		;None													
;* Output		;ready/Not ready = true/false 														
;* History		;(2018/12/17) 	    ;first written		;by S.Pairot		
;************************************************************************/
BOOL USART0_IsRxReady(void) {                                           //
                                                                        //
	return (BOOL)(USART0_rx_elements != 0);                             //
}                                                                       //

/************************************************************************
;* Module name	;USART0_IsRxReady	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;Check USART_0 is ready to write			
;* Details		;						
;* Input		;None													
;* Output		;ready/Not ready = true/false 														
;* History		;(2018/12/17) 	    ;first written		;by S.Pairot		
;************************************************************************/
BOOL USART0_IsTxReady(void) {                                           //
                                                                        //
	return (BOOL)(USART0_tx_elements != USART0_TX_BUFFER_SIZE);         //
}                                                                       //

/************************************************************************
;* Module name	;ISR(USART_RX_vect)	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;Interrupt service routine for RX complete		
;* Details		;					
;* Input		;None														
;* Output		;None														
;* History		;(2018/12/17)	;first written		;by S.Pairot		
;************************************************************************/
ISR(USART_RX_vect) {                                                    //
  UC L_tmphead;                                                         //
  UC L_data;                                                            //
                                                                        //
  L_data = UDR0;                                                      	// Read the received data 
                                                                        //
  L_tmphead = (USART0_rx_head + 1) % USART0_RX_BUFFER_SIZE;		        // Calculate buffer index (Ring buffer)
                                                                        //
  if (L_tmphead == USART0_rx_tail) {                                    //
		                                                                // ERROR! Receive buffer overflow
  } else {                                                              //
                                                                        //
    USART0_rxbuf[L_tmphead] = L_data;                                   // Store received data in buffer
	USART0_rx_head = L_tmphead;                                         // Store new index
	USART0_rx_elements++;                                               // Increment elements
	                                                                    //
  }                                                                     //
}                                                                       //

/************************************************************************
;* Module name	;ISR(USART_UDRE_vect)	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;Interrupt service routine for Data Register Empty	
;* Details		;					
;* Input		;None														
;* Output		;None														
;* History		;(2018/12/17)	;first written		;by S.Pairot		
;************************************************************************/
ISR(USART_UDRE_vect) {                                                  //
  UC L_tmptail;                                                         //
	                                                                    //
  if (USART0_tx_elements != 0) {                                        // Check if all data is transmitted
    L_tmptail = (USART0_tx_tail + 1) % USART0_TX_BUFFER_SIZE;           // Calculate buffer index
	UDR0 = USART0_txbuf[L_tmptail];                                     // Start transmission
    USART0_tx_tail = L_tmptail;                                         // Store new data index
	USART0_tx_elements--;                                               // Decrement elements
  }                                                                     //
	                                                                    //
  if (USART0_tx_elements == 0) {                                        // Transmission finished
    DIS_UDRE_INTR();                                                    // Disable UDRE interrupt
  }                                                                     //
}                                                                       //


