/*
; #######################################################################
; # 																	#
; # Copyright(C) 2013  Toshiba Carrier (Thailand) Co, Ltd.				#
; # All Rights Reserved.												#
; # 																	#
; # The information contained herein is confidential property of		#
; # Toshiba Carrier Corporation. The user, copying, transfer or 		#
; # disclosure of such information is prohibited except by express		#
; # written agreement with Toshiba Carrier (Thailand). 					#
; # 																	#
; # <Module name>														#
; # ir_ctrl.h															#
; # 																	#
; # <Module Description>												#
; # IR driver controller header module.									#
; # 																	#
; # <History>															#
; # 2013-01-19	Initial release. 										#
; # 																	#
; #######################################################################
*/
#ifndef _IR_CTRL_H_INCLUDE
#define _IR_CTRL_H_INCLUDE

#include <avr/io.h>
#include <avr/interrupt.h>

#include "TYPEDEF.H"

#define V_IR_MAXBUF		28				// Maximum buffer bytes per 1 frame
#define V_IR_MAXFRM		2				// Maximum frame

#define V_IR_IDLE		0				// Idle state 
#define V_IR_LEADERH	1				// Leader H state
#define V_IR_LEADERL	2				// Leader L state
#define V_IR_DATA		3				// Data state
#define V_IR_TRAILER	4				// Trailer state

struct t_frm {
	UC buf[V_IR_MAXBUF];				// IR data frame buffer
	UC m_bit;							// Max bit in frame
	UC n_bit;							// Now sending bit in frame 
};										//
struct t_ir {							//
	UC state;							// Communication state
	UC m_frm;							// Max frame to be send
	UC n_frm;							// Currently send frame count
	struct t_frm frm[V_IR_MAXFRM];		// Frame data
};

void IR_setFrmMax(UC);
void IR_setFrmBuf(UC,UC*,UC);
void IR_startTrans(void);
void IR_init(void);
FL	 IR_chkTrans(void);

#endif /* _IR_CTRL_H_INCLUDE */
