/*
; #######################################################################
; # 																	#
; # Copyright(C) 2018  Toshiba Carrier (Thailand) Co, Ltd.				#
; # All Rights Reserved.												#
; # 																	#
; # The information contained herein is confidential property of		#
; # Toshiba Carrier Corporation. The user, copying, transfer or 		#
; # disclosure of such information is prohibited except by express		#
; # written agreement with Toshiba Carrier (Thailand). 					#
; # 																	#
; # <Module name>														#
; # usart0.h															#
; # 																	#
; # <Module Description>												#
; # PC control header module.									        #
; # 																	#
; # <History>															#
; # 2018-12-17	Initial release. 										#
; # 																	#
; #######################################################################
*/

#ifndef PC_CTRL_H
#define PC_CTRL_H

/************************************************************************
;* Include Section
;************************************************************************/
#include "TYPEDEF.H"

/************************************************************************
;* Defines Section
;************************************************************************/

#ifdef	EXTR							
#undef	EXTR								
#endif
#ifdef	PC_CTRL_C					
#define EXTR								
#else									
#define EXTR extern						
#endif	

#ifndef DBG_MODE_ENA
#define DBG_MODE_ENA
#endif

#define V_PC_RX_BUF_SIZE 32
#define V_PC_TX_BUF_SIZE 32

#define V_PC_RX_TIMEOUT (10000/10)                                      // Receive data 10s timeout
#define V_PC_TX_TIMEOUT (10000/10)                                      // Transmit data 10s timeout

/************************************************************************
;* Variable Section
;************************************************************************/


/************************************************************************
;* Function Prototype Section
;************************************************************************/
EXTR void PC_init(US);
EXTR void PC_main(void);
EXTR void PC_Timer10ms(void);

#endif /*PC_CTRL_H*/
