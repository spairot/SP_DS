/*
; #######################################################################
; # 																	#
; # Copyright(C) 2018  Toshiba Carrier (Thailand) Co, Ltd.				#
; # All Rights Reserved.												#
; # 																	#
; # The information contained herein is confidential property of		#
; # Toshiba Carrier Corporation. The user, copying, transfer or 		#
; # disclosure of such information is prohibited except by express		#
; # written agreement with Toshiba Carrier (Thailand). 					#
; # 																	#
; # <Module name>														#
; # usart0.h															#
; # 																	#
; # <Module Description>												#
; # USART 0 driver header module.									    #
; # 																	#
; # <History>															#
; # 2018-12-17	Initial release. 										#
; # 																	#
; #######################################################################
*/

#ifndef USART0_DRIVER_H
#define USART0_DRIVER_H

/************************************************************************
;* Include Section
;************************************************************************/
#include "TYPEDEF.H"

/************************************************************************
;* Defines Section
;************************************************************************/

#ifdef	EXTR							
#undef	EXTR								
#endif
#ifdef	USART0_DRIVER_C					
#define EXTR								
#else									
#define EXTR extern						
#endif	

#define USART0_RX_BUFFER_SIZE 32
#define USART0_TX_BUFFER_SIZE 32

typedef enum{
   B_FALSE = 0,
   B_TRUE
} BOOL_t;

/************************************************************************
;* Variable Section
;************************************************************************/


/************************************************************************
;* Function Prototype Section
;************************************************************************/
EXTR void USART0_init(US);
EXTR UC   USART0_ReadChr(void);
EXTR void USART0_WriteChr(const UC);
EXTR BOOL_t  USART0_IsRxReady(void);
EXTR BOOL_t  USART0_IsRxReady(void);

#endif /*USART0_DRIVER_H*/
