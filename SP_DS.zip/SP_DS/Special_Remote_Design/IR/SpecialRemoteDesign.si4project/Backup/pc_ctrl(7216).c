/*
; #######################################################################
; # 																	#
; # Copyright(C) 2018  Toshiba Carrier (Thailand) Co, Ltd.				#
; # All Rights Reserved.												#
; # 																	#
; # The information contained herein is confidential property of		#
; # Toshiba Carrier Corporation. The user, copying, transfer or 		#
; # disclosure of such information is prohibited except by express		#
; # written agreement with Toshiba Carrier (Thailand). 					#
; # 																	#
; # <Module name>														#
; # pc_ctrl.c															#
; # 																	#
; # <Module Description>												#
; # PC control module       										    #
; # 																	#
; # <History>															#
; # 2018-12-17	Initial release. 										#
; # 																	#
; #######################################################################
*/

#define PC_CTRL_C

/************************************************************************
;* Include Section
;************************************************************************/
#include <string.h>
#include <avr/eeprom.h>
#include "pc_ctrl.h"
#include "usart0_driver.h"

/************************************************************************
;* Defines Section
;************************************************************************/
#define V_PC_CMD_INIT_DEVICE		0x00
#define V_PC_CMD_WRITE_DATA  		0x01
#define V_PC_CMD_WRITE_VERIFY  		0x02
#define V_PC_CMD_READ_DATA  		0x03

#define V_PC_CTRL_STS_NONE 			0x00
#define V_PC_CTRL_STS_SUCCESS   	0x01
#define V_PC_CTRL_STS_FAILURE   	0x02
#define V_PC_CTRL_STS_ERR_CHKSUM 	0x03
#define V_PC_CTRL_STS_ERR_TIMEOUT   0x04
#define V_PC_CTRL_STS_ERR_OVERFLOW  0x05

typedef struct {
  UC Header;
  UC PacketLength;
  UC Data[V_PC_RX_BUF_SIZE];
  UC CheckSum;
} PC_Packet_t, *PT_Packet_t;

typedef enum {
	V_PC_CTRL_STATE_INIT = 0,
    V_PC_CTRL_STATE_START,
	V_PC_CTRL_STATE_PACKLEN,
	V_PC_CTRL_STATE_COMMAND,
	V_PC_CTRL_STATE_DATLEN,
	V_PC_CTRL_STATE_DATA,
	V_PC_CTRL_STATE_CHKSUM,
	V_PC_CTRL_STATE_FINISH,
	V_PC_CTRL_STATE_ERROR,
} PC_Ctrl_State_t;

/************************************************************************
;* Variable Section
;************************************************************************/

PC_Ctrl_State_t pc_ctrl_rx_state;
PC_Ctrl_State_t pc_ctrl_tx_state;

static PC_Packet_t st_pc_data_buf_rx;
	#define V_RxCommand		 st_pc_data_buf_rx.Data[0]
	#define V_RxDataLen		 st_pc_data_buf_rx.Data[1]
	#define V_RxType		 st_pc_data_buf_rx.Data[2]
	#define V_RxTotalAddr    st_pc_data_buf_rx.Data[3]
	#define V_RxTotalAddrInv st_pc_data_buf_rx.Data[4]
	#define V_DataStart      5
static PC_Packet_t st_pc_data_buf_tx;
	#define V_TxCommand		 st_pc_data_buf_tx.Data[0]
	#define V_TxDataLen		 st_pc_data_buf_tx.Data[1]

static SS T10ms_rx_timeout;
static UC pc_count_data_length;
static UC pc_ctrl_rx_sts;

/************************************************************************
;* Function Prototype Section
;************************************************************************/

/************************************************************************
;* Module name	;PC_init	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;PC initial data				
;* Details		;						
;* Input		;None													
;* Output		;None														
;* History		;(2018/12/17) 	;first written		;by S.Pairot		
;************************************************************************/
void PC_init(US L_Baud) {                                               //
  USART0_init(L_Baud);                                                  // Init USART 0
  T10ms_rx_timeout = 0;                                                 //
  pc_count_data_length = 0;                                             //
  pc_ctrl_rx_state = 0;                                                 //
  pc_ctrl_tx_state = 0;                                                 //
  memset(&st_pc_data_buf_rx,0x00,sizeof(PC_Packet_t));                  //
  memset(&st_pc_data_buf_tx,0x00,sizeof(PC_Packet_t));                  //
}

/************************************************************************
;*	Module name ;PC_ChkSum	  ;ver1.0 (2018/12/17)	;by S.Pairot
;* -------------;--------------------------------------------------------
;*	Function	;8 Bits sum get
;*	Details 	;This function will return sum of 8bit buffer
;*	Input		;const UC *Lp_dat: Address of buffer data
;*				;UC L_len: Byte count of buffer
;*	Output		;Return 8 bits sum data
;*	History 	;2018/12/17 	  ;first written		;by S.Pairot
;************************************************************************/
UC PC_ChkSum(const UC *Lp_dat, UC L_len) {								//
	UC L_sumdat = 0;													//
	do {																//
		L_sumdat -= *Lp_dat; ++Lp_dat;									//
	} while (--L_len);													//
	return (L_sumdat);													//
}																		//

/************************************************************************
;* Module name	;PC_MakeTxData	;(2018/12/18) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;Prepare data buffer to send				
;* Details		;						
;* Input		;Command, Status
;* Output		;None														
;* History		;(2018/12/18) 	;first written		;by S.Pairot
;* Note         ;Start check sum from command
;* Packet data:
;* -----------------------------------------------------------------------------
;* | Header : Packet Length : Command : Data Length : Data 1-Data n : CheckSum |
;*-----------------------------------------------------------------------------
;************************************************************************/
void PC_MakeTxData(UC L_cmd, UC L_sts) {                                //
   switch (L_cmd) {                                                     //
     case V_PC_CMD_WRITE_DATA:                                          //
	 	st_pc_data_buf_tx.Header = 0xFF;                                // Set header
	 	st_pc_data_buf_tx.PacketLength = 4;                             // Set packet length
	 	st_pc_data_buf_tx.Data[0] = V_PC_CMD_WRITE_DATA;                // Set command
	 	st_pc_data_buf_tx.Data[1] = 1;                                  // Set data length
	 	st_pc_data_buf_tx.Data[2] = L_sts;                              // Set write status
	 	st_pc_data_buf_tx.CheckSum = PC_ChkSum(&st_pc_data_buf_tx.Data[0], st_pc_data_buf_tx.PacketLength-1); // Calculate check sum start from byte command 
	 	break;                                                          //
	  case V_PC_CMD_WRITE_VERIFY:                                       //
	  	break;                                                          //
	  case V_PC_CMD_READ_DATA:                                          //
	  	break;                                                          //
	  default:                                                          //
	    break;                                                          //
   }
} 
/************************************************************************
;* Module name	;PC_WriteAddrAndData		;(2018/12/19) 		;by S.Pairot			
;* -------------;--------------------------------------------------------
;* Function 	;Write Address and Data to EEPROM											
;* Details		;							
;* Input		;Address, pointer data														
;* Output		;None													
;* History		;(2018/11/12) 	;first written		;by S.Pairot		
;************************************************************************/
void PC_WriteAddrAndData(US L_addr, UC *L_pt_Data) {                    //
                                                                        //                                          
	eeprom_write_byte((uint8_t *)L_addr, *(uint8_t *)L_pt_Data);        //
                                                                        //
}
/************************************************************************/
/************************************************************************
;* Module name	;PC_DecodeCommand	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;PC decode rx command				
;* Details		;						
;* Input		;None											
;* Output		;None														
;* History		;(2018/12/17) 	;first written		;by S.Pairot
;* Packet data:
;* -----------------------------------------------------------------------------
;* | Header : Packet Length : Command : Data Length : Data 1-Data n : CheckSum |
;*-----------------------------------------------------------------------------
;************************************************************************/
UC read_data;
void PC_DecodeCommand(void) {                                           //
  US L_WriteAddr;                                                       //
  UC L_TotalAddr;                                                       //
  UC *Lpt_data;                                                         //

  st_pc_data_buf_rx.Data[V_DataStart] = 0x5E;   //--------------------debug
  st_pc_data_buf_rx.Data[V_DataStart+1] = 0xA1;
  st_pc_data_buf_rx.Data[V_DataStart+2] = 0x00;
  st_pc_data_buf_rx.Data[V_DataStart+3] = 0xFF;
  st_pc_data_buf_rx.Data[V_DataStart+4] = 0x3F;
  st_pc_data_buf_rx.Data[V_DataStart+5] = 0xC0;
  V_RxCommand = V_PC_CMD_WRITE_DATA;
  V_RxTotalAddr = 1;
                                                                        //
  switch (V_RxCommand) {                                                //
    case V_PC_CMD_WRITE_DATA:                                           //
                                                                        //
    	Lpt_data = &st_pc_data_buf_rx.Data[V_DataStart];                // Pointer to data
    	L_WriteAddr = V_ADDR_ADDR_TTL;                                  //
    	L_TotalAddr = 2;                                                // Address total + inverse
    	do {                                                            //
    	   PC_WriteAddrAndData(L_WriteAddr, Lpt_data);                  // Write total address
    	   read_data = eeprom_read_byte((const uint8_t *)L_WriteAddr);         //-----------------------debug
    	   //USART0_WriteChr(eeprom_read_byte((const uint8_t *)L_WriteAddr));   //-----------------------debug
    	   L_WriteAddr++;                                               // 
    	   Lpt_data++;                                                  //
		} while (--L_TotalAddr);                                        //
							                                            //																													//
		L_WriteAddr = V_ADDR_ADDR_CHG;									// Set change address
		L_TotalAddr = V_RxTotalAddr;									// Set address total
		do {															//
		   PC_WriteAddrAndData(L_WriteAddr, Lpt_data); 			        // Write change address
		   read_data = eeprom_read_byte((const uint8_t *)L_WriteAddr);//-----------------------debug
    	   //USART0_WriteChr(eeprom_read_byte((const uint8_t *)L_WriteAddr));   //-----------------------debug
		   L_WriteAddr++;                                               // 
		   Lpt_data++;                                                  //                                             
		} while (--L_TotalAddr);										//
		                                                                //																											//
		L_WriteAddr = V_ADDR_DATA_NEW;									// Set data new address
		L_TotalAddr = V_RxTotalAddr;									// Set address total
		do {															// 
		   PC_WriteAddrAndData(L_WriteAddr, Lpt_data); 			        // Write new data
		   read_data = eeprom_read_byte((const uint8_t *)L_WriteAddr);//-----------------------debug
    	   //USART0_WriteChr(eeprom_read_byte((const uint8_t *)L_WriteAddr));   //-----------------------debug
		   L_WriteAddr++;                                               // 
		   Lpt_data++;                                                  //                                             
		} while (--L_TotalAddr);										//
		                                                                //
		L_WriteAddr = V_ADDR_DATA_OLD;									// Set data old address
		L_TotalAddr = V_RxTotalAddr;									// Set address total
		do {															// 
		   PC_WriteAddrAndData(L_WriteAddr, Lpt_data); 			        // Write old data
		   read_data = eeprom_read_byte((const uint8_t *)L_WriteAddr);//-----------------------debug
    	   //USART0_WriteChr(eeprom_read_byte((const uint8_t *)L_WriteAddr));   //-----------------------debug
		   L_WriteAddr++;                                               // 
		   Lpt_data++;                                                  //                                             
		} while (--L_TotalAddr);										//
		                                                                //
		break;                                                          //
 	case V_PC_CMD_WRITE_VERIFY:                                         //
		break;                                                          //
	case V_PC_CMD_READ_DATA:                                            //
		break;                                                          //
    default:
    	break;
  }
}

/************************************************************************
;* Module name	;PC_RxInterrupt	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;PC rx interrupt manager				
;* Details		;						
;* Input		;None													
;* Output		;None														
;* History		;(2018/12/17) 	;first written		;by S.Pairot
;* Note         ;
;* Packet data:
;* -----------------------------------------------------------------------------
;* | Header : Packet Length : Command : Data Length : Data 1-Data n : CheckSum |
;*-----------------------------------------------------------------------------
;************************************************************************/
void PC_RxInterrupt(void) {                                             //
    UC L_data;                                                          //
                                                                        //
    L_data = USART0_ReadChr();                                          // Read 1 byte from UART 0  
                                                                        //
    switch (pc_ctrl_rx_state) {                                         // 
	  case V_PC_CTRL_STATE_INIT :                                       //
	  case V_PC_CTRL_STATE_START:                                       //
//		USART0_WriteChr('1');  //-------------------------------debug
	    if (L_data == 0xFF) {                                           // Check correct header
	      T10ms_rx_timeout = (SS)V_PC_RX_TIMEOUT;                       // Set timer 10s
	      pc_ctrl_rx_state = V_PC_CTRL_STATE_PACKLEN;                   // Set next state : check packet length
		}                                                               //
	  	break;                                                          //
	  case V_PC_CTRL_STATE_PACKLEN:                                     //    
//		USART0_WriteChr('2');  //-------------------------------debug
	    st_pc_data_buf_rx.PacketLength = L_data;                        // Store packet length
	    pc_ctrl_rx_state = V_PC_CTRL_STATE_COMMAND;                     // Set next state : get command
	    break;                                                          //
	  case V_PC_CTRL_STATE_COMMAND:                                     //
//	    USART0_WriteChr('3');  //-------------------------------debug
	    st_pc_data_buf_rx.Data[0] = L_data;                             // Store command
	    pc_ctrl_rx_state = V_PC_CTRL_STATE_DATLEN;                      // Set next state : get data length
	    break;                                                          //
	  case V_PC_CTRL_STATE_DATLEN:                                      //
//	    USART0_WriteChr('4');  //-------------------------------debug
	    st_pc_data_buf_rx.Data[1] = L_data;                             // Store data length
	    pc_count_data_length = 0;                                       // Init data count
	    pc_ctrl_rx_state = V_PC_CTRL_STATE_DATA;                        // Set next state : get data
	    break;                                                          //
	  case V_PC_CTRL_STATE_DATA:                                        //
//	    USART0_WriteChr('5');  //-------------------------------debug
        st_pc_data_buf_rx.Data[2 + pc_count_data_length] = L_data;      // Store data
        pc_count_data_length++;                                         // Increment data index
        if (pc_count_data_length >= V_PC_RX_BUF_SIZE) {                 // Check buffer over folw
            pc_ctrl_rx_sts = V_PC_CTRL_STS_ERR_OVERFLOW;                // Set error type
			pc_ctrl_rx_state = V_PC_CTRL_STATE_ERROR;                   //
		}                                                               //
		else if (pc_count_data_length >= st_pc_data_buf_rx.Data[1]) {   // store data finished check
	      pc_ctrl_rx_state = V_PC_CTRL_STATE_CHKSUM;                    // Set next state : check sum
		}                                                               //
	    break;                                                          //
	  case V_PC_CTRL_STATE_CHKSUM:                                      //
//		USART0_WriteChr('6');	//-------------------------------debug
		st_pc_data_buf_rx.Data[2 + pc_count_data_length] = L_data;      // Store sum data at the last byte
	    if (!PC_ChkSum(&st_pc_data_buf_rx.Data[0],st_pc_data_buf_rx.PacketLength)) { // Check sum OK
//    	  USART0_WriteChr('7');	//-------------------------------debug
    	  pc_ctrl_rx_sts = V_PC_CTRL_STS_SUCCESS;                       //
		  pc_ctrl_rx_state = V_PC_CTRL_STATE_FINISH;                    // Set next state : finished
	    } else {                                                        // Check sum error      
//    	  USART0_WriteChr('8');	//-------------------------------debug
		  pc_ctrl_rx_sts = V_PC_CTRL_STS_ERR_CHKSUM;                    // Set status
		  pc_ctrl_rx_state = V_PC_CTRL_STATE_ERROR;                     // Set next state
		}                                                               //
	    break;                                                          //
	  default:                                                          //
	  	break;                                                          //
  }                                     
}

/************************************************************************
;* Module name	;PC_TxInterrupt	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;PC tx interrupt manager				
;* Details		;						
;* Input		;None
;* Output		;None														
;* History		;(2018/12/17) 	;first written		;by S.Pairot
;* Note         ;
;* Packet data:
;* -----------------------------------------------------------------------------
;* | Header : Packet Length : Command : Data Length : Data 1-Data n : CheckSum |
;*-----------------------------------------------------------------------------
;************************************************************************/
void PC_TxInterrupt(void) {                                             //
  switch (pc_ctrl_tx_state) {                                           //
    case V_PC_CTRL_STATE_START:                                         //
        USART0_WriteChr(st_pc_data_buf_tx.Header);                      // Send header
		pc_ctrl_tx_state = V_PC_CTRL_STATE_PACKLEN;                     // Next: Send packet length
		break;                                                          //
	case V_PC_CTRL_STATE_PACKLEN:                                       //
        USART0_WriteChr(st_pc_data_buf_tx.PacketLength);                // Send Packet length
		pc_ctrl_tx_state = V_PC_CTRL_STATE_COMMAND;                     // Next: Send Command
		break;                                                          //
	case V_PC_CTRL_STATE_COMMAND:                                       //
        USART0_WriteChr(V_TxCommand);                                   // Send command
		pc_ctrl_tx_state = V_PC_CTRL_STATE_DATLEN;                      // Next: Send Data Length
		break;                                                          //
	case V_PC_CTRL_STATE_DATLEN:                                        //
        USART0_WriteChr(V_TxDataLen);                                   // Send Data length
        pc_count_data_length = 0;                                       // Init data count
		pc_ctrl_tx_state = V_PC_CTRL_STATE_DATA;                        // Next: Send Data 
		break;                                                          //
	case V_PC_CTRL_STATE_DATA:                                          //
        USART0_WriteChr(st_pc_data_buf_tx.Data[pc_count_data_length]);  // Send Data 
        if (++pc_count_data_length >= V_TxDataLen) {                    // Data send finished check
		  pc_ctrl_tx_state = V_PC_CTRL_STATE_CHKSUM;                    // Next: Send Sum data
		}                                                               //
		break;                                                          //
	case V_PC_CTRL_STATE_CHKSUM:                                        //
        USART0_WriteChr(st_pc_data_buf_tx.CheckSum);                    // Send command
		pc_ctrl_tx_state = V_PC_CTRL_STATE_INIT;                        // Next: Init/Idle state
		break;                                                          //
	default:                                                            // No case
		break;                                                          //
  } 
}

/************************************************************************
;* Module name	;PC_main	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;PC main function				
;* Details		;						
;* Input		;None													
;* Output		;None														
;* History		;(2018/12/17) 	;first written		;by S.Pairot		
;************************************************************************/
void PC_main(void) {                                                    //
  PC_DecodeCommand();  //----------------------------------debug
  if (T10ms_rx_timeout < 1) {											// Reciving timeout
      if (pc_ctrl_rx_state > V_PC_CTRL_STATE_START) {                   // Data receive in processing..
         pc_ctrl_rx_sts = V_PC_CTRL_STS_ERR_TIMEOUT;                    // Read timeout set
		 PC_MakeTxData((UC)V_PC_CMD_WRITE_DATA, pc_ctrl_rx_sts);		// Make Tx data	 
	     pc_ctrl_tx_state = V_PC_CTRL_STATE_START; 					    // Set tx state to start send data
      }                                                                 //
	  pc_ctrl_rx_state = V_PC_CTRL_STATE_INIT;							// Reset rx state
  }																	    //
                                                                        //
  if (pc_ctrl_rx_state == V_PC_CTRL_STATE_FINISH) {                     // Finished Rx
    PC_DecodeCommand();                                                 //
	PC_MakeTxData((UC)V_PC_CMD_WRITE_DATA, pc_ctrl_rx_sts);		        // Make Tx data
    //pc_ctrl_tx_state = V_PC_CTRL_STATE_START;                           // Set tx state to start send data
    pc_ctrl_rx_state = V_PC_CTRL_STATE_INIT;                            // init new data sequence
  }                                                                     //
                                                                        //
  if (pc_ctrl_rx_state == V_PC_CTRL_STATE_ERROR) {                      // Error Rx
    PC_MakeTxData((UC)V_PC_CMD_WRITE_DATA, pc_ctrl_rx_sts);		        // Make Tx data
    //pc_ctrl_tx_state = V_PC_CTRL_STATE_START;                           // Set tx state to start send data
    pc_ctrl_rx_state = V_PC_CTRL_STATE_INIT;                            // init new data sequence
  }                                                                     //                                                                       
                                                                        //                                                                        //
  if (USART0_IsRxReady()) {                                             // Have a data incomming
     PC_RxInterrupt();                                                  // Rx interrupt data manager
  }                                                                     //
                                                                        //
  if (pc_ctrl_tx_state) {					                            // Check tx state no idle
     PC_TxInterrupt();												    // call tx interupt manager
  }																	    //
}     

/************************************************************************
;* Module name	;PC_Timer10ms	;(2018/12/17) 		;by S.Pairot		
;* -------------;--------------------------------------------------------
;* Function 	;PC short 10ms timer			
;* Details		;Entering this function every 10ms						
;* Input		;None													
;* Output		;None														
;* History		;(2018/12/17) 	;first written		;by S.Pairot		
;************************************************************************/
void PC_Timer10ms(void) {                                               //
  if (T10ms_rx_timeout > 0)                                             //
  	T10ms_rx_timeout--;                                                 //
}

