// Title: Special IR signal
// CPU: ATMAGA48
// F_CPU: 1000000MHz
// Programmer: R.Chaiyasit
// Date: 2018/11/12

#include <avr/io.h>
#include <avr/sleep.h>
#include <avr/eeprom.h>

#include "TYPEDEF.H"
#include "GLOBAL.H"
#include "ir_ctrl.h"
#include "pc_ctrl.h"

//#include "usart0_driver.h"  //---------------------------debug


#ifndef	F_CPU
#define F_CPU 1000000UL
#endif

#define BAUD 4800
#define BAUD_PRESCALE (F_CPU / 16 / BAUD - 1)

#define KEY_PIN	PINC
#define KEY_SET	PC2
#define KEY_RTN	PC1

typedef struct {
	UC *pCode;
	UC Size;
} Code_t;

typedef enum {
	INIT_STATE,
	START_NEW_STATE,
	START_OLD_STATE,
	HEADER_STATE,
	ADDR_DATA_STATE,
	END_STATE,
	FAIL_STATE
} State_t;

volatile FL F_10ms;
UC key_state;
UC key_press;
UC ct0, ct1;

UC Header_End[] = {0xF2,0x0D,0x01,0xFE,0x81,0x30,0xB1};
UC Addres_Dat[] = {0xF2,0x0D,0x04,0xFB,0x81,0x20,0x3A,0x00,0xC8,0x00};
const Code_t CodeTable[] = {
{(UC*)&Header_End, sizeof(Header_End)},
{(UC*)&Addres_Dat, sizeof(Addres_Dat)}
};
Code_t *pCode_Header_End;
Code_t *pCode_Addr_Data;
State_t IR_State;
UC TotalAddrSend;
UC *pData_Send_Out;
UC IndexSend;
SS T10ms_TimerDelay;

/************************************************************************
;* Module name	;IO_init		;(2018/11/12) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR initialize												
;* Details		;Initialize IR port, timer and data							
;* Input		;None														
;* Output		;None														
;* History		;(2018/11/12) 	;first written		;by R.Chaiyasit
                ;(2018/12/17)   ;Add UART init pin  ;by S.Pairot
;************************************************************************/
void IO_init(void) {
	DDRC = 0b11111001;
	PORTC = 0b00000110;

	DDRD &= ~(1 << DDD0);                                               // Set pin D0 direction to input
	PORTD &= ~(1 << PIND0);                                             // Set Pin D0 pull mode : OFF
    DDRD |= (1 << DDD1);                                                // Set pin D1 direction to output 
	PORTD &= ~(1 << PIND1);                                             // Set Pin D1 pull mode : OFF
	
	TCCR0A = 0b00000010;
	TCCR0B = 0b00000100;
	TIMSK0 = 0b00000010;
	TIFR0  = 0b00000010;
	OCR0A  = OCR0A =  F_CPU / 256 / 100 - 1;		                    // 100Hz
}
/************************************************************************/
/************************************************************************
;* Module name	;key_timerproc		;(2018/11/12) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR initialize												
;* Details		;							
;* Input		;None														
;* Output		;None														
;* History		;(2018/11/12) 	;first written		;by R.Chaiyasit			
;************************************************************************/
void key_timerproc(void) {
	UC L_i, L_key;
	
	L_key = 0;
	if (!(KEY_PIN & _BV(KEY_SET))) L_key |= _BV(KEY_SET);
	if (!(KEY_PIN & _BV(KEY_RTN))) L_key |= _BV(KEY_RTN);
	
	L_i = key_state ^ L_key;
	ct0 = ~( ct0 & L_i);
	ct1 = ct0 ^ (ct1 & L_i);
	L_i &= ct0 & ct1;
	key_state ^= L_i;
	key_press |= key_state & L_i;
}
/************************************************************************/
/************************************************************************
;* Module name	;chk_key_press		;(2018/11/12) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR initialize												
;* Details		;							
;* Input		;None														
;* Output		;None														
;* History		;(2018/11/12) 	;first written		;by R.Chaiyasit			
;************************************************************************/
UC chk_key_press(UC L_key_mask) {
	cli();
	L_key_mask &= key_press;
	key_press ^= L_key_mask;
	sei();
	return (L_key_mask);
}
/************************************************************************/
/************************************************************************
;* Module name	;LoadAddrAndData		;(2018/11/12) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR initialize												
;* Details		;							
;* Input		;None														
;* Output		;None														
;* History		;(2018/11/12) 	;first written		;by R.Chaiyasit			
;************************************************************************/
FL LoadAddrAndData(US L_addr, UC *L_pt_DataUse) {
	UC L_E2DatUse;
	UC L_E2DatInv;
	L_E2DatUse = eeprom_read_byte((const uint8_t *)L_addr);
	L_E2DatInv = eeprom_read_byte((const uint8_t *)L_addr+1);
	if ((L_E2DatUse ^ L_E2DatInv) == 255) {
		*L_pt_DataUse = L_E2DatUse;
		return (1);							// E2 read OK return 1
	}
	return (0);								// Fail return 0
}
/************************************************************************/
/************************************************************************
;* Module name	;DT_init		;(2018/11/12) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR initialize												
;* Details		;							
;* Input		;None														
;* Output		;None														
;* History		;(2018/11/12) 	;first written		;by R.Chaiyasit			
;************************************************************************/
void DT_init(void) {
	US L_ReadAddr;
	UC L_TotalAddr;
	UC L_Index;

	DataReadVerify = OFF;                                   // Init verify status
	L_ReadAddr = V_ADDR_ADDR_TTL;							// Total Address block load
	if (LoadAddrAndData(L_ReadAddr,&TotalAddr)) {
		
		L_TotalAddr = TotalAddr;
		L_ReadAddr = V_ADDR_ADDR_CHG;						// Address block
		L_Index = 0;
		do {
			if (LoadAddrAndData(L_ReadAddr,&AddrChg[L_Index])) {		
			    //USART0_WriteChr(AddrChg[L_Index]);  //------------------------debug
				L_Index++;
				L_ReadAddr += 2;
			} else {
				TotalAddr = 0;
				//USART0_WriteChr('A');  //------------------------debug
				break;
			}
		} while (--L_TotalAddr);
		
		L_TotalAddr = TotalAddr;
		if (L_TotalAddr) {
			L_ReadAddr = V_ADDR_DATA_NEW;					// New Data block load
			L_Index = 0;
			do {
				if (LoadAddrAndData(L_ReadAddr,&DataNew[L_Index])) {
					//USART0_WriteChr(DataNew[L_Index]);	//------------------------debug
					L_Index++;
					L_ReadAddr += 2;
				} else {
					TotalAddr = 0;
					//USART0_WriteChr('B');  //------------------------debug
					break;
				}
			} while (--L_TotalAddr);
		}
		
		L_TotalAddr = TotalAddr;
		if (L_TotalAddr) {
			L_ReadAddr = V_ADDR_DATA_OLD;					// Old Data block load
			L_Index = 0;
			do {
				if (LoadAddrAndData(L_ReadAddr,&DataOld[L_Index])) {
					//USART0_WriteChr(DataOld[L_Index]);	//------------------------debug
					L_Index++;
					L_ReadAddr += 2;
				} else {
					TotalAddr = 0;
					//USART0_WriteChr('C');  //------------------------debug
					break;
				}
			} while (--L_TotalAddr);
		}
		
	} else {
		TotalAddr = 0;
	}
	
	if (TotalAddr == 0 || TotalAddr > 10) {
		IR_State = FAIL_STATE;
		DataReadVerify = ON;                                 // Data verify OK
	}
	
	key_press = 0;
}
/************************************************************************/
/************************************************************************
;* Module name	;IR_calSum		;(2018/11/12) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR initialize												
;* Details		;							
;* Input		;None														
;* Output		;None														
;* History		;(2018/11/12) 	;first written		;by R.Chaiyasit			
;************************************************************************/			
void IR_calSum(UC *LptDat, UC L_Size) {
	UC L_Sum;
	L_Size -= 1;
	L_Sum = 0;
	do {
		L_Sum ^= *LptDat++;
	} while (--L_Size);
	*LptDat = L_Sum;
}
/************************************************************************/
/************************************************************************
;* Module name	;main		;(2018/11/12) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR initialize												
;* Details		;							
;* Input		;None														
;* Output		;None														
;* History		;(2018/11/12) 	;first written		;by R.Chaiyasit			
;************************************************************************/
int main(void) {

	DT_init();
	IO_init();
	PC_init(BAUD_PRESCALE);
	IR_init();
	sei();
	do {
		if (F_10ms) {
			F_10ms = OFF;

			if (IR_chkTrans()) {
				key_press = 0;							// Ban key press during IR is being send
				continue;
			}
			
			if (T10ms_TimerDelay > 0) {
				--T10ms_TimerDelay;
				key_press = 0;							// Ban key press during IR is being send
				continue;
			}
			
			if (IR_State != INIT_STATE) {
				key_press = 0;							// Ban key press during IR is being send
			}

			PC_Timer10ms();                             // Pc short 10ms timer 
			PC_main();                                  // Pc main function
			
			switch (IR_State) {
				
				case INIT_STATE:
					if (chk_key_press(_BV(KEY_SET))) {
						IR_State = START_NEW_STATE;
					} else if (chk_key_press(_BV(KEY_RTN))) {
						IR_State = START_OLD_STATE;
					}
					break;
					
				case START_NEW_STATE:
					TotalAddrSend = TotalAddr;
					pCode_Header_End = (Code_t *)&CodeTable[0];
					pCode_Addr_Data = (Code_t *)&CodeTable[1];
					pData_Send_Out = &DataNew[0];
					IR_State = HEADER_STATE;
					break;
					
				case START_OLD_STATE:
					TotalAddrSend = TotalAddr;
					pCode_Header_End = (Code_t *)&CodeTable[0];
					pCode_Addr_Data = (Code_t *)&CodeTable[1];
					pData_Send_Out = &DataOld[0];
					IR_State = HEADER_STATE;
					break;
					
				case HEADER_STATE:
					IR_setFrmMax(1);
					IR_setFrmBuf(0,(UC*)pCode_Header_End->pCode,pCode_Header_End->Size);
					T10ms_TimerDelay = (SS)200/10;
					IR_State = ADDR_DATA_STATE;
					IR_startTrans();
					break;
					
				case ADDR_DATA_STATE:
					Addres_Dat[6] = AddrChg[IndexSend];
					Addres_Dat[8] = *(pData_Send_Out+IndexSend);
					IR_calSum(&Addres_Dat[0],pCode_Addr_Data->Size);
					IR_setFrmMax(1);
					IR_setFrmBuf(0,(UC*)pCode_Addr_Data->pCode,pCode_Addr_Data->Size);
					T10ms_TimerDelay = (SS)200/10;
					TotalAddrSend--;
					if (TotalAddrSend != 0) {
						IndexSend++;
						IR_State = ADDR_DATA_STATE;
					} else {
						IndexSend = 0;
						IR_State = END_STATE;
					}
					IR_startTrans();
					break;
					
				case END_STATE:
					IR_setFrmMax(1);
					IR_setFrmBuf(0,(UC*)pCode_Header_End->pCode,pCode_Header_End->Size);
					T10ms_TimerDelay = (SS)1000/10;
					IR_State = INIT_STATE;
					IR_startTrans();
					break;
				
				case FAIL_STATE:
					break;
				
				default:
					break;
			}			
			
			key_press = 0;							// Ban key press during IR is being send
		}
				
	} while (1);
}
/************************************************************************/
/************************************************************************
;* Module name	;TIMER0_COMPA_vect	;(2018/11/12) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR initialize												
;* Details		;							
;* Input		;None														
;* Output		;None														
;* History		;(2018/11/12) 	;first written		;by R.Chaiyasit			
;************************************************************************/
ISR (TIMER0_COMPA_vect) {
	key_timerproc();
	F_10ms = ON;
}
/************************************************************************/
