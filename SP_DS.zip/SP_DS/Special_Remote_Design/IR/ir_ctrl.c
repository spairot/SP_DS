/*
; #######################################################################
; # 																	#
; # Copyright(C) 2013  Toshiba Carrier (Thailand) Co, Ltd.				#
; # All Rights Reserved.												#
; # 																	#
; # The information contained herein is confidential property of		#
; # Toshiba Carrier Corporation. The user, copying, transfer or 		#
; # disclosure of such information is prohibited except by express		#
; # written agreement with Toshiba Carrier (Thailand). 					#
; # 																	#
; # <Module name>														#
; # ir_ctrl.c															#
; # 																	#
; # <Module Description>												#
; # IR driver controller module.										#
; # 																	#
; # <History>															#
; # 2013-01-19	Initial release. 										#
; # 																	#
; #######################################################################
*/

/************************************************************************
;* Include Section
;************************************************************************/
#include "ir_ctrl.h"
/************************************************************************
;* Defines Section
;************************************************************************/
#define V_CLK			(1000)											// Timer tick period [ns]
#define V_TTOWN			(544000/V_CLK)									//
#define V_TLEADER		(4500000/V_CLK)									// Leader time (4.5ms)
#define V_TTRAIL		(7000000/V_CLK)									// Trailer time (7ms)
																		//
#define IR_INIT_PORT()	DDRB |= _BV(PB3); PORTB &= ~_BV(PB3);			//
#define	IR_INIT_TIMER()	TCCR1B = 0b00000001								// Initialize Timer (Timer1 for transmission timing no prescaller)
																		//
#define IR_TX_38K()		OCR2A  = 13; TCNT2  = 0							// Set IR out frequency to 38kHz
#define IR_TX_ON()		TCCR2A = 0b01000010; TCCR2B = 0b10000001 		// Start IR out
#define IR_TX_OFF()		TCCR2A = 0; TCCR2B = 0; TCNT2 = 0				// Stop IR out
#define IR_TX_TEST()	TCCR2A & _BV(COM2A0)							// Check if IR is being transmitted or not
																		//
#define	ISR_COMPARE()	ISR(TIMER1_COMPA_vect)							// Timer compare match ISR
#define IR_COMP_ENA(n)	OCR1A = TCNT1 + (n); TIFR1 = _BV(OCF1A);\
						TIMSK1 |= _BV(OCIE1A)							// Enable compare interrupt n count after now
#define IR_COMP_DIS()	TIMSK1 &= ~_BV(OCIE1A)							// Disable compare interrupt 
#define IR_COMP_NEXT(n)	OCR1A += (n)									// Tx: Increase compare register by n count 
																		//
/************************************************************************
;* Variable Section
;************************************************************************/
static volatile struct t_ir IR;											//

/************************************************************************
;* Function Prototype Section
;************************************************************************/
extern void DT_init(void);

/************************************************************************
;* Module name	;ISR_COMPARE	;(2013/01/19) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR output compare interrupt service routine				
;* Details		;Interrupt for drive IR on each state						
;* Input		;None														
;* Output		;None														
;* History		;(2013/01/19) 	;first written		;by R.Chaiyasit			
;************************************************************************/
ISR_COMPARE() {															//
	struct t_frm *Lpt_Fm;												//
	UC L_st,L_b,L_d;													//
	US L_tm;															//
																		//
	Lpt_Fm = (struct t_frm *)&IR.frm[IR.n_frm];							//
	L_st = IR.state;													//
	L_b = Lpt_Fm->n_bit;												//
																		//
	if (L_st == V_IR_TRAILER) {											//
		if (IR.n_frm < IR.m_frm) {										//
			IR.state = V_IR_LEADERH;									//
			IR_TX_ON();													//
			IR_COMP_ENA(V_TLEADER);										//
		} else {														//
			IR_TX_OFF();												//
			IR_COMP_DIS();												// Disable compare 
			IR.n_frm = 0;												//
			IR.state = V_IR_IDLE;										// Send data finish 
		} 																//
	} else if (L_st == V_IR_LEADERH) {									//
		IR_TX_OFF();													//
		IR.state = V_IR_LEADERL;										//
		IR_COMP_NEXT(V_TLEADER);										//
	} else {															//
		if (IR_TX_TEST()) {												//
			IR_TX_OFF();												//
			if (L_b < Lpt_Fm->m_bit) {									// Is there a bit to be sent?
				L_b >>= 3;												//
				L_d = Lpt_Fm->buf[L_b];									//
				L_tm = (L_d & 128) ? 3*V_TTOWN : V_TTOWN;				//
				Lpt_Fm->buf[L_b] = L_d << 1;							//
				Lpt_Fm->n_bit++;										//
				IR_COMP_NEXT(L_tm);										//
			} else {													//
				Lpt_Fm->n_bit = 0;										//
				IR.n_frm++;												//
				IR.state = V_IR_TRAILER;								//
				IR_COMP_NEXT(V_TTRAIL);									//
			}															//
		} else {														//
			IR_TX_ON();													// Carrier frequency on
			IR.state = V_IR_DATA;										//
			IR_COMP_NEXT(V_TTOWN);										//
		}																//
	}																	//
}																		//
/************************************************************************/
/************************************************************************
;* Module name	;IR_setFrmMax	;(2013/01/19) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR set maximum frame										
;* Details		;Set maximum frame data										
;* Input		;UC L_frm: Maximum frame number								
;* Output		;None														
;* History		;(2013/01/19) 	;first written		;by R.Chaiyasit			
;************************************************************************/
void IR_setFrmMax(UC L_frm) {											//
	if (L_frm <= V_IR_MAXFRM && !IR_chkTrans()) {						//
		IR.m_frm = L_frm;												//
	}																	//
}																		//
/************************************************************************/
/************************************************************************
;* Module name	;IR_setFrmBuf	;(2013/01/19) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR set ftame buffer data									
;* Details		;Set frame buffer data 										
;* Input		;UC L_frm: Frame number										
;*				;UC *Lpt_buf: Point to input buffer 						
;*				;UC L_size: Input buffer size								
;* Output		;None														
;* History		;(2013/01/19) 	;first written		;by R.Chaiyasit			
;************************************************************************/
void IR_setFrmBuf(UC L_frm, UC *Lpt_buf, UC L_size) {					//
	UC L_count;															//
																		//
	L_count = 0;														//
	if (L_frm < V_IR_MAXFRM && !IR_chkTrans()) {						//
		IR.frm[L_frm].m_bit = (UC)(L_size<<3);							//
		do {															//
			IR.frm[L_frm].buf[L_count] = *Lpt_buf;						//
			Lpt_buf++;													//
			L_count++;													//
		} while (--L_size);												//
	}																	//
}																		//
/************************************************************************/
/************************************************************************
;* Module name	;IR_startTrans	;(2013/01/19) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR start transfer data										
;* Details		;Start to send buffer data of each frame 					
;* Input		;None														
;* Output		;None														
;* History		;(2013/01/19) 	;first written		;by R.Chaiyasit			
;************************************************************************/
void IR_startTrans(void) {												//
	if (IR.m_frm && !IR_chkTrans()) {									//
		IR.state = V_IR_LEADERH;										//
		IR_TX_ON();														//
		IR_COMP_ENA(V_TLEADER);											//
	}																	//
}																		//
/************************************************************************/
/************************************************************************
;* Module name	;IR_init		;(2013/01/19) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR initialize												
;* Details		;Initialize IR port, timer and data							
;* Input		;None														
;* Output		;None														
;* History		;(2013/01/19) 	;first written		;by R.Chaiyasit			
;************************************************************************/
void IR_init(void) {													//
	UC L_cfrm;															//
																		//
	IR_INIT_PORT();														//
	IR_INIT_TIMER();													//
	IR_TX_38K();														//
	IR_TX_OFF();														//
																		//
	IR.m_frm = 0;														//
	IR.n_frm = 0;														//
	L_cfrm = 0;															//
	do {																//
		IR.frm[L_cfrm].m_bit = 0;										//
		IR.frm[L_cfrm].n_bit = 0;										//
	} while (++L_cfrm < V_IR_MAXFRM);									//
}																		//
/************************************************************************/
/************************************************************************
;* Module name	;IR_chkTrans	;(2013/01/19) 		;by R.Chaiyasit			
;* -------------;--------------------------------------------------------
;* Function 	;IR check transfer data										
;* Details		;Checking under transfer data or not ?						
;* Input		;None														
;* Output		;FL: OFF=Not in transfer status, ON=During transfer data	
;* History		;(2013/01/19) 	;first written		;by R.Chaiyasit			
;************************************************************************/
FL IR_chkTrans(void) {													//
	return ((IR.state==V_IR_IDLE) ? OFF : ON);							//
}																		//
/************************************************************************/
