﻿#define DEBUG_MODE_ENABLE

using System;
using System.Data;
using System.Windows.Forms;
using System.IO.Ports;  // Serial port
using System.IO;
using Excel;           // Excel control
using Microsoft.Office.Interop.Excel;
using DataTable = System.Data.DataTable;
using System.Threading;
using System.Diagnostics;
using MenuItem = System.Windows.Forms.MenuItem;
using Action = System.Action;
using Application = System.Windows.Forms.Application;

namespace SpecialRemoteUi
{
    public partial class FormMain : Form
    {
        /*Global Variable define*/
        public UInt16 SerialTimeoutSec = 1000;
        static UInt16 BUFPAGE = 256;
        public int selectRow;
        bool debugModeEnable = false;
        internal delegate void SerialDataReceivedEventHandlerDelegate(
        object sender, SerialDataReceivedEventArgs e);
        delegate void SetTextCallback(byte[] data);

        public class DataPacket
        {
            public byte Header;        // Packet header 0xFF
            public byte PacketLength;  // Packet length not include header
            public byte Command;       // Command
            public byte DataLength;    // Data length
            public byte[] Data;        // Data buffer
            public byte Sum;           // Sum of data
        }

        enum TUARTCmd
        {
            /*0x00*/    CMD_InitialDevice = 0,  // Init device
            /*0x01*/    CMD_WriteData,          // Write data
            /*0x02*/    CMD_VerifyData,         // Verify data
            /*0x03*/    CMD_ReadData,           // Read data
        };

        public FormMain()                     // Form main start init
        {                                     // 
            InitializeComponent();            // Component init

            /*Context menu write click*/
            
            ContextMenu cm = new ContextMenu();
            MenuItem mi = new MenuItem("Cut");
            mi.Click += new EventHandler(mi_Cut);
            cm.MenuItems.Add(mi);

            mi = new MenuItem("Copy");
            mi.Click += new EventHandler(mi_Copy);
            cm.MenuItems.Add(mi);

            mi = new MenuItem("Paste");
            mi.Click += new EventHandler(mi_Paste);
            cm.MenuItems.Add(mi);

            mi = new MenuItem("Clear");
            mi.Click += new EventHandler(mi_Clear);
            cm.MenuItems.Add(mi);

            rtbDebug.ContextMenu = cm;
            
        }

        /*
         Function : FormMain_Load
         Detail   : Event trigger when main form is loaded
         Input    : object sender, EventArgs e
         Output   : None
         History  : 2018-11-10 First written by S.Pairot
        */
        private void FormMain_Load(object sender, EventArgs e)
        {
            MAIN_SettingControl(ControlEvent.INIT);
        }

        /*
        Function : FormMain_FormClosing
        Detail : Event trigger when form is closing
        Input  : object sender, FormClosingEventArgs e
        Output : None
        History : 2018-11-10 First written by S.Pairot
        */
        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            try { if (serialPort1.IsOpen) serialPort1.Close(); }  // close serial port when open
            catch (Exception) { }                                 // Exception
        }

        #region ControlSetting
        /*
        Function : MAIN_SettingControl
        Detail   : Enable/Disble all window form control
        Input    : ControlEvent InputEvent
        Output   : None
        History  : 2018-11-15 First written by S.Pairot
        */
        enum ControlEvent
        {
            INIT = 0,           // 0 : Initial
            SERIAL_SETTING,     // 1 : Serial port setting
            SERIAL_CONNECTED,   // 2 : Serial port connect event
            SERIAL_DISCONNECT,  // 3 : Serial port disconnect 
            LOAD_EXCEL_FILE,    // 4 : Load excel file
            LOAD_DATA_FILE,     // 5 : Load data from file
            MANUAL_EDIT_DATA,   // 6 : Manual data edit
        }
        private void MAIN_SettingControl(ControlEvent InputEvent)
        {

            switch (InputEvent) {
                case ControlEvent.INIT:
                    btnWrite.Enabled = false;         // Disable write button
                    btnVerify.Enabled = false;        // Disable verify button
                    btnRead.Enabled = false;          // Disable read button
                    btnConnect.Enabled = false;       // Disable connect button
                    btnDisConnect.Enabled = false;    // Disable disconnect button
                    btnEdit.Enabled = false;          // disable edit button control
                    btnDelete.Enabled = false;        // disable delete button control
                    btnAdd.Enabled = false;           // Disable add button
                    btnSave.Enabled = false;          // Disable save button
                    tabPageDbg.Enabled = false;       // Disable tab debug
                                                      // Menu group disable
                    connectToolStripMenuItem.Enabled = false;
                    disconnectToolStripMenuItem.Enabled = false;
                    saveToolStripMenuItem.Enabled = false;
                    break;
                case ControlEvent.SERIAL_SETTING:
                    btnConnect.Enabled = true;                    // Enable connect button
                    btnDisConnect.Enabled = true;                 // Enable disconnect button
                    connectToolStripMenuItem.Enabled = true;
                    disconnectToolStripMenuItem.Enabled = false;
                    if (debugModeEnable) tabPageDbg.Enabled = true;
                    else tabPageDbg.Enabled = false;
                    break;
                case ControlEvent.SERIAL_CONNECTED:
                    btnConnect.Visible = false;                   // button Connect disappear
                    btnDisConnect.Visible = true;                 // button Disconnect appear
                    if (dataGridViewCode.DataSource != null)
                    {
                        btnWrite.Enabled = true;                  // button write enable   
                        btnDelete.Enabled = true;                 // Enable delete button
                        btnEdit.Enabled = true;                   // Enable edit button
                    }
                    btnSetting.Enabled = false;                   // Disable setting button                  
                    btnVerify.Enabled = true;                     // button verify enable
                    btnRead.Enabled = true;                       // Enable read button
                    connectToolStripMenuItem.Enabled = false;
                    disconnectToolStripMenuItem.Enabled = true;
                    openToolStripMenuItem.Enabled = true;
                    settingToolStripMenuItem.Enabled = false;
                    tabControl2.SelectedIndex = 1;                // Tab edit display
                    break;
                case ControlEvent.SERIAL_DISCONNECT:
                    btnConnect.Visible = true;                    // button Connect appear
                    btnDisConnect.Visible = false;                // button disConnect disappear
                    btnWrite.Enabled = false;                     // Disable write button
                    btnVerify.Enabled = false;                    // Disable verify button
                    btnRead.Enabled = false;                      // Disable read button
                    btnSetting.Enabled = true;                    // Enable setting button

                    connectToolStripMenuItem.Enabled = true;
                    disconnectToolStripMenuItem.Enabled = false;
                    settingToolStripMenuItem.Enabled = true;
                    break;
                case ControlEvent.LOAD_EXCEL_FILE:
                    btnSave.Enabled = true;                       // button save enable 
                    btnDelete.Enabled = true;                     // Enable delete button
                    if (serialPort1.IsOpen)
                    {
                        btnWrite.Enabled = true;                  // Enable write button
                        btnVerify.Enabled = true;                 // Enable verify button
                        btnRead.Enabled = true;                   // Enable read button
                        btnEdit.Enabled = true;                   // Enable edit button
                    }
                    saveToolStripMenuItem.Enabled = true;
                    break;
                case ControlEvent.LOAD_DATA_FILE:
                    btnNew.Enabled = true;                        // Enable New button
                    btnOpen.Enabled = true;                       // Enable Open button
                    btnAdd.Enabled = false;                       // Disable add button
                    btnEdit.Enabled = false;
                    if (dataGridViewCode.DataSource == null)
                    {
                        btnWrite.Enabled = false;                 // Disable write button
                        btnDelete.Enabled = false;                //
                        btnSave.Enabled = false;                  //
                    }
                    openToolStripMenuItem.Enabled = true;
                    tabControl1.SelectedIndex = 0;
                    break;
                case ControlEvent.MANUAL_EDIT_DATA:
                    btnNew.Enabled = false;                       // Disable new button
                    btnOpen.Enabled = false;                      // Disable Open button
                    if (dataGridViewCode.DataSource != null)      //
                    {
                        btnSave.Enabled = true;                   // disable file manager control
                        btnEdit.Enabled = true;
                        btnDelete.Enabled = true;
                        if (serialPort1.IsOpen)
                        {
                            btnWrite.Enabled = true;              // button write enable   
                            btnVerify.Enabled = true;             // button verify enable
                            btnRead.Enabled = true;               // Enable read button
                        }
                    }
                    else
                    {
                        btnWrite.Enabled = false;                 // Disable write button
                        btnDelete.Enabled = false;                //
                        btnSave.Enabled = false;                  //
                    }
                    btnAdd.Enabled = true;                        // Enable add button
                    openToolStripMenuItem.Enabled = false;
                    tabControl1.SelectedIndex = 0;
                    break;
                default:
                    break;
            }
        }
        #endregion

        #region SerialPortConnect
        /*
        Function : btnConnect_Click
        Detail   : Serial port connect start
        Input    : None
        Output   : None
        History  : 2018-11-10 First written by S.Pairot
        */
        private void MAIN_SerialPortConnect()
        {
            //SettingForm L_FormSetting = new SettingForm();
            /*Serial data recieved interrupt handler*/
            serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(serialPort_DataReceived);
            try
            {
                if (serialPort1.IsOpen) serialPort1.Close();  // Comport arlready opened? then close it
                serialPort1.Open();                           // Serial port open
            }                                                 //
            catch (Exception ex)                              // Fault Exception
            {                                                 // User notify
                MessageBox.Show("Can't Open Port!!" + "\n" + ex.Message, "Connect Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (serialPort1.IsOpen)                           // Serial port open succeed
            {                                                 //
                MAIN_SettingControl(ControlEvent.SERIAL_CONNECTED);
                serialPort1.WriteTimeout = SerialTimeoutSec * 10; // Serial port write timeout 10s
                serialPort1.ReadTimeout = SerialTimeoutSec * 10;  // Serial port read timeout 10s
            }
        }
        /*Serial port connect button click*/
        private void btnConnect_Click(object sender, EventArgs e)
        {
            MAIN_SerialPortConnect();                          // serial port connect
        }
        /*Serial port connect by menu select*/
        private void connectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MAIN_SerialPortConnect();                          // serial port connect
        }

        /*
        Function : MAIN_SerialPortDisConnect
        Detail   : Serial port disconnect
        Input    : None
        Output   : None
        History  : 2018-11-10 First written by S.Pairot
        */
        private void MAIN_SerialPortDisConnect()
        {
            serialPort1.DataReceived -= new System.IO.Ports.SerialDataReceivedEventHandler(serialPort_DataReceived);
            try
            {
                if (serialPort1.IsOpen) serialPort1.Close(); // serial port close
            }
            catch (Exception ex)                             // error while close
            {                                                // notify error message
                MessageBox.Show("Can't close Port!!" + "\n" + ex.Message, "Connect Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (!serialPort1.IsOpen)                        // Already close comport 1
            {                                               //
                MAIN_SettingControl(ControlEvent.SERIAL_DISCONNECT);  // update control setting
            }
        }
        /*Serial port disconnect button click*/
        private void btnDisConnect_Click(object sender, EventArgs e)
        {
            MAIN_SerialPortDisConnect();                    // serial port disconnect
        }
        /*Serial port disconnect by menu select*/
        private void disconnectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MAIN_SerialPortDisConnect();                    // serial port disconnect
        }
        #endregion

        #region SerialPortSetting
        /*
        Function : MAIN_SerialPortSetting
        Detail   : Configuration Settings (Serialport,..)
        Input    : None
        Output   : None
        History  : 2018-11-10 First written by S.Pairot
        */
        private void MAIN_SerialPortSetting()
        {
            using (SettingForm FormSetting = new SettingForm() { Setting = new SettingData() })
            {
                if (FormSetting.ShowDialog() == DialogResult.OK)                  // If child Form setting <OK button click
                {                                                                 // 
                    serialPort1.PortName = FormSetting.Setting.ComPortName; // Port name get from Setting Form
                    serialPort1.BaudRate = FormSetting.Setting.Baudrate;    // Baudrate name get from Setting Form
                    serialPort1.DataBits = FormSetting.Setting.DataBits;    // DataBits get from Setting Form
                    serialPort1.Parity = FormSetting.Setting.Parity;        // Parity get from Setting Form
                    serialPort1.StopBits = FormSetting.Setting.StopBits;    // StopBit get from Setting Form
                    debugModeEnable = FormSetting.Setting.debugModeEnable;  // Debug mode enable setting
                    MAIN_BackupSetting(FormSetting.Setting);                // backup data
                    MAIN_SettingControl(ControlEvent.SERIAL_SETTING);       //
                }                                                           //

            }
        }
        /*Serial port setting button click*/
        private void btnSetting_Click(object sender, EventArgs e)
        {
            MAIN_SerialPortSetting();
        }
        /*Serial port setting by menu select*/
        private void settingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MAIN_SerialPortSetting();
        }
        #endregion

        /*
        Function : MAIN_BackupSetting
        Detail   : Backup data setting
        Input    : SerialPort sr (serial port parameter)
        Output   : None
        History  : 2018-11-12 First written by S.Pairot
        */
        #region BackupSetting
        private void MAIN_BackupSetting(SettingData set) {
            BackupData.ComPortName = set.ComPortName;            // PortName Back up data 
            BackupData.Baudrate = Convert.ToInt32(set.Baudrate); // BaudRate Back up data 
            BackupData.DataBits = Convert.ToInt16(set.DataBits); // DataBits Back up data 
            BackupData.Parity = set.Parity;                      // Parity Back up data
            BackupData.StopBits = set.StopBits;                  // StopBits Back up data
            BackupData.debugModeEnable = set.debugModeEnable;    // Debuf Enabled Back up data 
        }

        #endregion

        /*
        Function : MAIN_OpenFile
        Detail   : Open excel file
        Input    : None
        Output   : None
        History  : 2018-11-12 First written by S.Pairot
        */
        #region OpenFile
        DataSet result;
        private void MAIN_OpenFile()                                                                       //
        {                                                                                                  //
            using (OpenFileDialog ofd = new OpenFileDialog()                                               // use open file dialog
            { Filter = "Excel workbook 97-2003|*.xls|Excel workbook|*.xlsx", ValidateNames = true }) // set file filter
            {                                                                                              //
                if (ofd.ShowDialog() == DialogResult.OK)                                                   // If click OK on open dialog popup window
                {                                                                                          // use file stream control file access
                    FileStream fs = File.Open(ofd.FileName, FileMode.Open, FileAccess.Read);               // 
                    IExcelDataReader reader;                                                               //
                    if (ofd.FilterIndex == 1) reader = ExcelReaderFactory.CreateBinaryReader(fs);          // Excel 97-2003 .xls
                    else reader = ExcelReaderFactory.CreateOpenXmlReader(fs);                              // Excel .xlsx
                    reader.IsFirstRowAsColumnNames = true;                                                 // 
                    result = reader.AsDataSet();                                                           //
                    cboFile.Items.Clear();                                                                 //
                    foreach (DataTable dt in result.Tables)                                                //
                        cboFile.Items.Add(dt.TableName);                                                   // Loop Add sheet name to comboBox
                    cboFile.SelectedIndex = 0;                                                             // Display 1st item
                    txtPath.Text = ofd.FileName;                                                           // Show path file
                    reader.Close();                                                                        // Close file reader control
                }                                                                                          //
            }
        }
        /*Open file by open button click*/
        private void btnOpen_Click(object sender, EventArgs e)
        {
            try
            {
                MAIN_OpenFile();                                    // Open existing excel file
                MAIN_SettingControl(ControlEvent.LOAD_EXCEL_FILE);  // update control seting
            }
            catch (Exception ex) {                                  // Show error message
                /*Open fail notify*/
                MessageBox.Show("Can't Open File!!!" + "\n" + ex.Message, "Load Error",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        /*Open file by open by menu open*/
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                MAIN_OpenFile();                                    // Open existing excel file         
                MAIN_SettingControl(ControlEvent.LOAD_EXCEL_FILE);  // update control seting
            }
            catch (Exception ex)
            {
                /*Open fail notify*/
                MessageBox.Show("Can't Open File!!!" + "\n" + ex.Message, "Load Error",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void cboFile_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridViewCode.DataSource = result.Tables[cboFile.SelectedIndex];
        }

        #endregion

        #region newFile
        /*
        Function : MAIN_CreateNewFile
        Detail   : Create new excel file
        Input    : None
        Output   : bool result
        History  : 2018-11-13 First written by S.Pairot
        */
        string filePathName = null;   // global file path name
        private bool MAIN_CreateNewFile()
        {
            string newFileName = null;
            bool result = true;
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
            Workbook wb = excel.Workbooks.Add(XlSheetType.xlWorksheet);
            Worksheet ws = (Worksheet)excel.ActiveSheet;
            try
            {
                filePathName = System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory.ToString(), "ExcelSheet.xls");
                if (excel == null)                                                    // can not create excel application?
                {
                    MessageBox.Show("Excel is not properly installed!!!");            // user notifi
                    result = false;
                }
                excel.Visible = false;                                                // activie excel application

                /*check file alredy have existed*/
                string fileNameOnly = Path.GetFileNameWithoutExtension(filePathName); // Get current file name
                string extension = Path.GetExtension(filePathName);                   // Get current file extension
                string path = Path.GetDirectoryName(filePathName);                    // Get current path name
                string newFilePathName = filePathName;                                // Set current path name to new path name
                int count = 1;                                                        // File count index
                while (File.Exists(newFilePathName))                                  // check existing file name
                {                                                                     //
                    newFileName = string.Format("{0}({1})", fileNameOnly, count++);   // create new file name "Name(1)", "Name(2)",...
                    newFilePathName = Path.Combine(path, newFileName + extension);    // set new file path name
                }

                if (newFilePathName != null) filePathName = newFilePathName;          // assign new file path name

                ws.SaveAs(filePathName, XlFileFormat.xlWorkbookDefault, Type.Missing, // Save file
                    Type.Missing, false, false, XlSaveAsAccessMode.xlNoChange,
                    XlSaveConflictResolution.xlLocalSessionChanges, Type.Missing, Type.Missing);
                excel.Quit();
            }
            catch (Exception ex)                                                      // Something wrong?
            {
                /*Create fail notify*/
                MessageBox.Show("Can't create new file!!!" + "\n" + ex.Message, "Create Error",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                result = false;
            }
            finally                                                                   // final operation
            {
                excel.Quit();                                                         // exit excel application
                wb = null;                                                            // release excel workbook
                excel = null;                                                         // release excel worksheet
            }
            return result;
        }
        /*
        Function : MAIN_OpenNewFile
        Detail   : Open new excel file
        Input    : None
        Output   : None
        History  : 2018-11-13 First written by S.Pairot
        */
        private void MAIN_OpenNewFile()
        {
            //string filePathName = System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory.ToString(), "ExcelSheet.xls");
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
            Workbook wb; //= excel.Workbooks.Add(XlSheetType.xlWorksheet);
            Worksheet ws; //= (Worksheet)excel.ActiveSheet;
            try
            {
                if (excel == null)
                {
                    MessageBox.Show("Excel is not properly installed!!!");
                    return;
                }

                excel.Visible = true;
                //object misValue = System.Reflection.Missing.Value;

                wb = excel.Workbooks.Open(filePathName, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
                ws = (Worksheet)wb.Worksheets.get_Item(1);

                txtPath.Text = filePathName;                                          // show file path in text box
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can't open new file!!!" + "\n" + ex.Message, "Open Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                //excel.Quit();
                //wb = null;
                //excel = null;
            }
            //wb.Close(true, misValue, misValue);
            //excel.Quit();

            //releaseObject(ws);
            //releaseObject(wb);
            //releaseObject(excel);
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Unable to release the Object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        /*New file by btnNew click*/
        private void btnNew_Click(object sender, EventArgs e)
        {
            if (true == MAIN_CreateNewFile())   // Could be create new file successfully?
            {                                   //
                MAIN_OpenNewFile();             // Open file that create
            }
        }

        /*New file by open menu click*/
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (true == MAIN_CreateNewFile())   // Could be create new file successfully?
            {                                   //
                MAIN_OpenNewFile();             // Open file that create
            }                                   //
        }
        #endregion

        #region SaveFile
        /*
        Function : MAIN_ExportToExcel
        Detail   : Save current excel file
        Input    : None
        Output   : None
        History  : 2018-11-13 First written by S.Pairot
        */
        private void MAIN_ExportToExcel()
        {
            // Creating a Excel object. 
            Microsoft.Office.Interop.Excel._Application excel = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel._Workbook workbook = excel.Workbooks.Add(Type.Missing);
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

            try
            {

                worksheet = workbook.ActiveSheet;

                worksheet.Name = "SpecialRemoteSetting_File";

                int cellRowIndex = 1;
                int cellColumnIndex = 1;

                //Loop through each row and read value from each column. 
                for (int i = 0; i < dataGridViewCode.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < dataGridViewCode.Columns.Count; j++)
                    {
                        // Excel index starts from 1,1. As first Row would have the Column headers, adding a condition check. 
                        if (cellRowIndex == 1)
                        {
                            worksheet.Cells[cellRowIndex, cellColumnIndex] = dataGridViewCode.Columns[j].HeaderText;
                        }
                        else
                        {
                            worksheet.Cells[cellRowIndex, cellColumnIndex] = dataGridViewCode.Rows[i - 1].Cells[j].Value.ToString();
                        }
                        cellColumnIndex++;
                    }
                    cellColumnIndex = 1;
                    cellRowIndex++;
                }

                //Getting the location and file name of the excel to save from user. 
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                saveDialog.FilterIndex = 2;

                if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    workbook.SaveAs(saveDialog.FileName);
                    MessageBox.Show("Save file Successful", "Save Status",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Can't save file!!!" + "\n" + ex.Message, "Save Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                excel.Quit();
                workbook = null;
                excel = null;
            }

        }
        /*New file by save button click*/
        private void btnSave_Click(object sender, EventArgs e)
        {
            MAIN_ExportToExcel();
        }
        /*New file by save menu click*/
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MAIN_ExportToExcel();
        }
        #endregion

        #region ReceiveData
        /*
        Function : serialPort_DataReceived
        Detail   : event handler serial port data receive
        Input    : SerialDataReceivedEventArgs
        Output   : None
        History  : 2018-11-15 First written by S.Pairot
        */
        void serialPort_DataReceived(object s, SerialDataReceivedEventArgs e)
        {
            //Queue<byte> recievedData = new Queue<byte>();        // byte data queue
            //List<byte> recievedData = new List<byte>();
            byte[] data = new byte[serialPort1.BytesToRead];       // create data buffer with automatic resize upto serial data in byte
            serialPort1.Read(data, 0, data.Length);                // serial data read
                                                                   //
                                                                   //data.ToList().ForEach(b => recievedData.Enqueue(b));  // add data to queue
                                                                   // foreach (byte item in data) recievedData.Add(item);    // add data to list
            this.BeginInvoke(new SetTextCallback(processData), new object[] { data }); // callback function <processdata

            Thread.Sleep(100);                                     // wait 100 ms
        }

        /*
        Function : processData
        Detail   : Data received processing
        Input    : byte[] data
        Output   : None
        History  : 2018-11-20 First written by S.Pairot
        */
        public byte[] packet = new byte[BUFPAGE * 8];  // 256*8 = 2048 bytes
        delegate void ChangeMyTextDelegate();
        int packetLength = 0;
        int receivedDataIndex = 0;
        enum ProDataState
        {
            Idle = 0,
            Start,
            PacketLen,
            DataStore,
            FinishedStore,
        };
        ProDataState rx_state = new ProDataState();

        void processData(byte[] recievedData)
        {
            CalCheckSum sum = new CalCheckSum();
            if (recievedData.Length < 1) return;                      // No have data
            try
            {
                for (int i = 0; i < recievedData.Length; i++)         // Copy all data received loop
                {
                    if (rx_state == ProDataState.Idle)                // Idle state
                    {
                        if (recievedData[i] == 255)                   // check packet header
                            rx_state = ProDataState.PacketLen;        // Set next state
                    }                                                 //
                    else if (rx_state == ProDataState.PacketLen)      //
                    {                                                 //
                        packetLength = recievedData[i];               // get packet data length
                        if (packetLength > 0)                         // No empty
                        {                                             //
                            rx_state = ProDataState.DataStore;        // Set next state
                        }                                             //
                    }                                                 //
                    else if (rx_state == ProDataState.DataStore)      //
                    {                                                 //
                        packet[receivedDataIndex] = recievedData[i];  // Store data in buffer
                        if (++receivedDataIndex == packetLength)      // Store data finished?
                        {                                             //
                            rx_state = ProDataState.FinishedStore;    // Set finished state
                            break;                                    // Exit loop
                        }                                             //
                    }                                                 //
                }                                                     //
                if (rx_state == ProDataState.FinishedStore)           // Finished data
                {
                    if (debugModeEnable == true) {
                        ConvertData cv = new ConvertData();
                        byte[] L_data = new byte[1];
                        rtbDebug.AppendText("RX: ");
                        for (int num = 0; num < packetLength; num++)
                        {
                            L_data[0] = packet[num];
                            rtbDebug.AppendText(cv.ByteToHexString(L_data) + "");
                        }
                        rtbDebug.AppendText("\n");
                        rtbDebug.SelectionStart = rtbDebug.Text.Length;
                        rtbDebug.ScrollToCaret();
                    }
                    if (0 == sum.SUM_GetSumData(packet))
                    {
                        // Check sum OK
                        MAIN_DecodeRxData(packet);
                    }
                    else {
                        // Check sum NG
                        MessageBox.Show("Read:Check sum error!!", "Message", 
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    rx_state = ProDataState.Idle;                    // Set idle state
                    receivedDataIndex = 0;                           // Clear received data index
                    Array.Clear(packet, 0, packet.Length);           // Removing all elements from Queue 
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message, "Message",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                MAIN_SerialPortInit();
            }
        }
        /*
        Function : MAIN_DecodeRxData()
        Detail   : UART serial port initial
        Input    : Rx buffer
        Output   : None
        History  : 2018-12-20 First written by S.Pairot
        */
        public void MAIN_DecodeRxData(byte[] rx_buf) {
            TUARTCmd Command = (TUARTCmd)rx_buf[0];
            byte Status = 0;

            switch (Command) {
                case TUARTCmd.CMD_WriteData:
                    Status = rx_buf[2];
                    if (Status == 1)                                          // Write OK
                    {
                        MessageBox.Show("Write data successful!","Message",
                            MessageBoxButtons.OK,MessageBoxIcon.Information);
                    }
                    else {                                                    // Write NG
                        MessageBox.Show("Write data failed!", "Message",
                         MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    break;
                case TUARTCmd.CMD_VerifyData:
                    Status = rx_buf[2];
                    if (Status == 1)                                          // Verify OK
                    {
                        MessageBox.Show("Data Verify OK!", "Message",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else                                                      // Verify NG
                    {
                        MessageBox.Show("Data Verify NG!", "Message",
                         MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    break;
                case TUARTCmd.CMD_ReadData:
                    ConvertData cv = new ConvertData();
                    byte[] L_data = new byte[1];
                    byte DataLen = rx_buf[1];
                    byte TotalAddr = rx_buf[2];
                    ListViewItem item = new ListViewItem(TotalAddr.ToString());
                    for (byte i=0; i<DataLen-1; i++)
                    {
                        L_data[0] = rx_buf[3 + i];
                        item.SubItems.Add(cv.ByteToHexString(L_data));
                    }
                    listView.Items.Add(item);
                    break;
                default:
                    break;
            }
        }
        /*
        Function : MAIN_SerialPortInit
        Detail   : UART serial port initial
        Input    : None
        Output   : None
        History  : 2018-12-18 First written by S.Pairot
        */
        public void MAIN_SerialPortInit()
        {
            rx_state = ProDataState.Idle;                     // Init rx state
            receivedDataIndex = 0;                            // Reset
            Array.Clear(packet, 0, packet.Length);            // Removing all elements from buffer 
        }
        #endregion

        /*
        Function : MAIN_PrepareDataSend
        Detail   : UART send data
        Input    : send_packet
        Output   : None
        History  : 2018-11-15 First written by S.Pairot
        */
        #region SendData
        public void MAIN_UartSendData(DataPacket send_packet) {
            byte[] send_buff = new byte[send_packet.PacketLength+2]; // Header + Packet Length
            int index = 0;

            send_buff[0] = send_packet.Header;                       // Packet header
            send_buff[1] = send_packet.PacketLength;                 // Packet length (Excluding header) -> Command + Data length + Data... + sum
            send_buff[2] = send_packet.Command;                      // Packet command
            send_buff[3] = send_packet.DataLength;                   // Pcket data length (only data length)

            for (index = 0; index < send_packet.DataLength; index++) // Copy data loop
            {
                send_buff[4 + index] = send_packet.Data[index];      // copy data
            }

            send_buff[4 + index] = send_packet.Sum;                    // Packet sum -> Command + data length + data..

            /*Send data via serial port*/
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Write(send_buff, 0, send_packet.PacketLength + 2);

                }
                catch (TimeoutException)
                {
                    /*Write data time out notify*/
                    MessageBox.Show("Time out error!!!", "Read/Write Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                /*Port is closed notify*/
                MessageBox.Show("Serial Port not connect!!!", "Read/Write Error",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        /*
        Function : MAIN_PrepareDataSend
        Detail   : prepare data for send out via UART
                 : Loop read following until total address (Vertical read)
                 : 1.Read address and its inverse
                 : 2.Read New data and its inverse
                 : 3.Read Old data and its inverse
        Input    : None
        Output   : None
        History  : 2018-11-15 First written by S.Pairot
                 : 2018-12-19 Edit data send packet by S.Pairot
        */
        public void MAIN_UartWriteData()
        {
            DataPacket packet = new DataPacket();
            ConvertData cv = new ConvertData();
            byte[] data_buff = new byte[BUFPAGE * 1];   // Send bufer syze 256*8 = 2048 bytes
            UInt16 col = 0, pre_col = 0, pre_row = 0;
            byte total_addr = 0;
            UInt16 index = 0;
            string strTemp = null;
            string chk_data = null;
            bool result = false;
            CalCheckSum sum = new CalCheckSum();
            byte[] temp_data;

            //for (UInt16 counter = 0; counter < (dataGridViewCode.Rows.Count); counter++)
            UInt16 counter = 0;
            do
            {
                try
                {
                    var value = dataGridViewCode.Rows[counter].Cells[col].Value;  // get value from data grid cell
                    if (value != null) chk_data = value.ToString();               // Convert value to string when value not null
                    else chk_data = null;

                    if (string.IsNullOrEmpty(chk_data) || (index >= (data_buff.Length - 4))) { break; }  // exit loop when data read end line or overflow

                    //Get A/C Type
                    strTemp = dataGridViewCode.Rows[counter].Cells[col].Value.ToString();
                    if (strTemp == "FCU") data_buff[index] = 1;
                    else if (strTemp == "CDU") data_buff[index] = 2;
                    index++;
                    col++;

                    //Get Total address
                    strTemp = dataGridViewCode.Rows[counter].Cells[col].Value.ToString();
                    temp_data = cv.HexToByte(strTemp);                      // convert hex data to dec
                    data_buff[index] = temp_data[0];
                    total_addr = temp_data[0];                              // get total address
                    index++;
                    col++;

                    //Get Total address inverse
                    strTemp = dataGridViewCode.Rows[counter].Cells[col].Value.ToString();
                    temp_data = cv.HexToByte(strTemp);
                    data_buff[index] = temp_data[0];
                    index++;
                    col++;

                    //Get Address & its inverse
                    pre_col = col;                                           // get column
                    pre_row = counter;                                       // get row
                    for (int i = 0; i < total_addr * 2; i++)                 // total_addr*2 ihis include its inverse data 
                    {
                        strTemp = dataGridViewCode.Rows[pre_row].Cells[col].Value.ToString();
                        temp_data = cv.HexToByte(strTemp);                   // convert hex data to dec
                        data_buff[index] = temp_data[0];
                        index++;
                        if (++col > (pre_col + 1))                           // Limit 2 column
                        {
                            col = pre_col;                                   // Reload column counter
                            pre_row++;                                       // Increat to next row
                        }
                    }
                    col += 2;                                                // jump 2 column

                    //Get new data & its inverse
                    pre_col = col;                                           // 
                    pre_row = counter;
                    for (int i = 0; i < total_addr * 2; i++)
                    {
                        strTemp = dataGridViewCode.Rows[pre_row].Cells[col].Value.ToString();
                        temp_data = cv.HexToByte(strTemp);
                        data_buff[index] = temp_data[0];
                        index++;
                        if (++col > (pre_col + 1))                           // Limit 2 column
                        {
                            col = pre_col;                                   // Reload column counter
                            pre_row++;                                       // Increat to next row
                        }
                    }
                    col += 2;

                    //Get old data and its inverse
                    pre_col = col;
                    pre_row = counter;
                    for (int i = 0; i < total_addr * 2; i++)
                    {
                        strTemp = dataGridViewCode.Rows[pre_row].Cells[col].Value.ToString();
                        temp_data = cv.HexToByte(strTemp);
                        data_buff[index] = temp_data[0];
                        index++;
                        if (++col > (pre_col + 1))                           // Limit 2 column
                        {
                            col = pre_col;                                   // Reload column counter
                            pre_row++;                                       // Increat to next row
                        }
                    }

                    col = 0;                                                 // finish reset column count
                    counter += total_addr;                                   // Next row
                    result = true;                                           // Set result
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Prepare data Error: " + ex.Message, "Data Error",
                                      MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    result = false;
                    break;
                }
            } while (counter < (dataGridViewCode.Rows.Count));
             
            if (true == result)
            {
                packet.Header = 255;                      // Set packet header
                packet.PacketLength = (byte)(index + 3);  // Addition Command + Data Length + sum
                packet.Command = (byte)TUARTCmd.CMD_WriteData;
                packet.DataLength = (byte)index;          // Data length only
                packet.Data = data_buff;                  // Data
                byte[] sum_buf = new byte[index + 2];     // Addition Command + Data Length
                sum_buf[0] = packet.Command;              // Start sum from Command
                sum_buf[1] = packet.DataLength;           // add data length
                for (int i=0; i<packet.DataLength; i++) { // data
                    sum_buf[2 + i] = packet.Data[i];      //
                }                                         //
                packet.Sum = sum.SUM_GetSumData(sum_buf);  // calculate check sum
                MAIN_UartSendData(packet);                // UART send out
            }
        }
        #endregion

        /*Control Read, Write, Verify*/
        #region control
        private void btnWrite_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
            MAIN_UartWriteData();
            MAIN_SerialPortInit();
        }
        /*
        Function : btnRead_Click
        Detail   : read data command send
        Input    : system sender, arg
        Output   : None
        History  : 2018-12-15 First written by S.Pairot
        */
        private void btnRead_Click(object sender, EventArgs e)
        {
            DataPacket packet = new DataPacket();  // create new packet object
            CalCheckSum sum = new CalCheckSum();
            byte[] data_buf = new byte[1] { 0 };   // create byte data, init = 0
            byte[] sum_buf = new byte[3];          // command + data length + data
            tabControl1.SelectedIndex = 1;         // Tab read display

            packet.Header = 0xFF;                  // Header
            packet.PacketLength = 4;               // All data length exclude header
            packet.Command = (byte)TUARTCmd.CMD_ReadData;  // Command
            packet.DataLength = 1;                 // Data length
            packet.Data = data_buf;                // Data dummy
            sum_buf[0] = packet.Command;           // sum prepare
            sum_buf[1] = packet.DataLength;        // sum prepare
            sum_buf[2] = packet.Data[0];           // sum prepare
            packet.Sum = sum.SUM_GetSumData(sum_buf);  // calculate check sum
            MAIN_UartSendData(packet);             // UART send out
        }
        /*
        Function : btnVerify_Click
        Detail   : Verify data command send
        Input    : system sender, arg
        Output   : None
        History  : 2018-12-15 First written by S.Pairot
        */
        private void btnVerify_Click(object sender, EventArgs e)
        {
            DataPacket packet = new DataPacket();  // create new packet object
            CalCheckSum sum = new CalCheckSum();
            byte[] data_buf = new byte[1] { 0 };   // create byte data, init = 0
            byte[] sum_buf = new byte[3];          // command + data length + data
            tabControl1.SelectedIndex = 1;         // Tab read display

            packet.Header = 0xFF;                  // Header
            packet.PacketLength = 4;               // All data length exclude header
            packet.Command = (byte)TUARTCmd.CMD_VerifyData;  // Command
            packet.DataLength = 1;                 // Data length
            packet.Data = data_buf;                // Data dummy
            sum_buf[0] = packet.Command;           // sum prepare
            sum_buf[1] = packet.DataLength;        // sum prepare
            sum_buf[2] = packet.Data[0];           // sum prepare
            packet.Sum = sum.SUM_GetSumData(sum_buf);  // calculate check sum
            MAIN_UartSendData(packet);             // UART send out
        }

        private void ShowWaitDialog(Action codeToRun)
        {
            ManualResetEvent dialogLoadedFlag = new ManualResetEvent(false);

            // open the dialog on a new thread so that the dialog window gets
            // drawn. otherwise our long running code will run and the dialog
            // window never renders.
            (new Thread(() =>
            {
                Form waitDialog = new Form()
                {
                    Name = "WaitForm",
                    Text = "Please Wait...",
                    ControlBox = false,
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    StartPosition = FormStartPosition.CenterParent,
                    Width = 240,
                    Height = 50,
                    Enabled = true
                };

                ProgressBar ScrollingBar = new ProgressBar()
                {
                    Style = ProgressBarStyle.Marquee,
                    Parent = waitDialog,
                    Dock = DockStyle.Fill,
                    Enabled = true
                };

                waitDialog.Load += new EventHandler((x, y) =>
                {
                    dialogLoadedFlag.Set();
                });

                waitDialog.Shown += new EventHandler((x, y) =>
                {
                    // note: if codeToRun function takes a while it will 
                    // block this dialog thread and the loading indicator won't draw
                    // so launch it too in a different thread
                    (new Thread(() =>
                    {
                        codeToRun();

                        // after that code completes, kill the wait dialog which will unblock 
                        // the main thread
                        this.Invoke((MethodInvoker)(() => waitDialog.Close()));
                    })).Start();
                });

                this.Invoke((MethodInvoker)(() => waitDialog.ShowDialog(this)));
            })).Start();

            while (dialogLoadedFlag.WaitOne(100, true) == false)
                Application.DoEvents(); // note: this will block the main thread once the wait dialog shows
        }

        #endregion

        /*Support menu right click*/
        #region rtbDspData Righ click menu
       
        void mi_Cut(object sender, EventArgs e)
        {
            rtbDebug.Cut();
        }
        void mi_Copy(object sender, EventArgs e)
        {
            rtbDebug.Copy();
        }
        void mi_Paste(object sender, EventArgs e)
        {
            rtbDebug.Paste();
        }
        void mi_Clear(object sender, EventArgs e)
        {
            rtbDebug.Clear();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtbDebug.Cut();
        }
        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtbDebug.Copy();
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtbDebug.Paste();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtbDebug.Clear();
        }
       
        #endregion

        
        #region ExitForm
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            serialPort1.DataReceived -= new System.IO.Ports.SerialDataReceivedEventHandler(serialPort_DataReceived);
            try
            {
                if (serialPort1.IsOpen) serialPort1.Close(); // serial port close
            }
            catch (Exception )                               // error while close
            {                                                // notify error message
            }
            this.Close();
        }
        #endregion

        #region New window
        private void newWindowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormMain frm = new FormMain();
            frm.StartPosition = FormStartPosition.Manual;
            frm.ShowDialog();
        }

        private void btnNewWindow_Click(object sender, EventArgs e)
        {
            FormMain frm = new FormMain();
            frm.StartPosition = FormStartPosition.Manual;
            frm.ShowDialog();
        }
        #endregion

        #region View
        private void writeWindowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;  // Show write window
        }
        private void readWindowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;  // Show read window
        }
        #endregion

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (AboutForm AboutFrm = new AboutForm() { })
            {
                AboutFrm.ShowDialog();
            }
                   
        }
        #region UserGuide
        private void userGuideToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (UserGuide user = new UserGuide() { })
            {
                user.ShowDialog();
            }
        }
        #endregion

        #region Manual Add data
        DataTable table = new DataTable();
        public void AddDataGridviewColumnHeader()
        {
            // Add column to datatable
            if (dataGridViewCode.Columns.Contains("ID") == false)  // Check no existing column header
            {
                // Add column header
                try
                {
                    table.Columns.Add("ID", typeof(string));
                    table.Columns.Add("Type", typeof(string));
                    table.Columns.Add("Address", typeof(string));
                    table.Columns.Add("~Address", typeof(string));
                    table.Columns.Add("New Data", typeof(string));
                    table.Columns.Add("~New Data", typeof(string));
                    table.Columns.Add("Base Data", typeof(string));
                    table.Columns.Add("~Base Data", typeof(string));
                    dataGridViewCode.DataSource = table;
                }
                catch (Exception ex) {
                    MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Add new form add send object
            using (AddEditData frm = new AddEditData() { ManualEditInfo = new ManualEdit() })
            {
                if (frm.ShowDialog() == DialogResult.OK)  // Click button OK in sub form
                {
                    AddDataGridviewColumnHeader();
                    // Add data to ddata table
                    table.Rows.Add(frm.ManualEditInfo.ID, 
                                    frm.ManualEditInfo.Type,
                                     frm.ManualEditInfo.E2Address,
                                      frm.ManualEditInfo.E2AddressInv,
                                       frm.ManualEditInfo.E2Data,
                                        frm.ManualEditInfo.E2DataInv,
                                         frm.ManualEditInfo.E2BaseData,
                                          frm.ManualEditInfo.E2BaseDataInv);
                    dataGridViewCode.DataSource = table;
                    MAIN_SettingControl(ControlEvent.MANUAL_EDIT_DATA);
                }
            }
        }

        ManualEdit m_info = new ManualEdit();
        private void dataGridViewCode_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // get datagridview select row
            selectRow = e.RowIndex;
            DataGridViewRow row = dataGridViewCode.Rows[selectRow];

            try
            {
                // Kept data cell click to m_info
                m_info.ID = dataGridViewCode.CurrentRow.Cells[0].Value.ToString();
                m_info.Type = dataGridViewCode.CurrentRow.Cells[1].Value.ToString();
                m_info.E2Address = dataGridViewCode.CurrentRow.Cells[2].Value.ToString();
                m_info.E2AddressInv = dataGridViewCode.CurrentRow.Cells[3].Value.ToString();
                m_info.E2Data = dataGridViewCode.CurrentRow.Cells[4].Value.ToString();
                m_info.E2DataInv = dataGridViewCode.CurrentRow.Cells[5].Value.ToString();
                m_info.E2BaseData = dataGridViewCode.CurrentRow.Cells[6].Value.ToString();
                m_info.E2BaseDataInv = dataGridViewCode.CurrentRow.Cells[7].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (m_info != null)
            {
                using (AddEditData frm = new AddEditData() { ManualEditInfo = m_info })  // Send data gridview current select to sub form
                {
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        try
                        {
                            // Save back data to datagridview
                            DataGridViewRow row = dataGridViewCode.Rows[selectRow];
                            row.Cells[0].Value = frm.ManualEditInfo.ID;
                            row.Cells[1].Value = frm.ManualEditInfo.Type;
                            row.Cells[2].Value = frm.ManualEditInfo.E2Address;
                            row.Cells[3].Value = frm.ManualEditInfo.E2AddressInv;
                            row.Cells[4].Value = frm.ManualEditInfo.E2Data;
                            row.Cells[5].Value = frm.ManualEditInfo.E2DataInv;
                            row.Cells[6].Value = frm.ManualEditInfo.E2BaseData;
                            row.Cells[7].Value = frm.ManualEditInfo.E2BaseDataInv;
                            btnEdit.Focus();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int SelectRow;
            try
            {
                SelectRow = dataGridViewCode.CurrentCell.RowIndex;
                dataGridViewCode.Rows.RemoveAt(SelectRow);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" +"Empty row","Message",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        #endregion

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void radLoadDataFile_CheckedChanged(object sender, EventArgs e)
        {
            MAIN_SettingControl(ControlEvent.LOAD_DATA_FILE);  // update control setting
            dataGridViewCode.DataSource = null;                // Clear data grid view data source
            dataGridViewCode.Refresh();                        // refresh it
        }

        private void radManualEdit_CheckedChanged(object sender, EventArgs e)
        {
            MAIN_SettingControl(ControlEvent.MANUAL_EDIT_DATA);  // update control setting
            dataGridViewCode.DataSource = null;                  // Clear data grid view data source
            dataGridViewCode.Refresh();                          // refresh it
            txtPath.Text = "";                                   // Clear text file path
            cboFile.Items.Clear();                               // Clear combbox sheet name
        }
    }
}
