﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports; /*For serial port control setting*/

namespace SpecialRemoteUi
{
    public partial class SettingForm : Form
    {
        public SettingData Setting { get; set; }               // Serial boject class (from SerialPortSetting.cs)
        public SettingForm()
        {
            InitializeComponent();
        }

        private void SettingForm_Load(object sender, EventArgs e)
        {
            if (tabSetting.SelectedIndex == 0)                  // Teb Serial is selected
            {                                                   //
                btnSettingFindComPort.Enabled = true;           // Enable Find Comport button
            }                                                   //
            else                                                //
            {                                                   //
                btnSettingFindComPort.Enabled = false;          // Disable Find Comport button
            }                                                   //

            /*Initial setting comport get from backup data first*/
            SETTING_SetComPortName();                           // Port name configuration 
            if (BackupData.Baudrate > 0) cmbSettingBaudrate.Text = BackupData.Baudrate.ToString(); 
            else cmbSettingBaudrate.Text = "4800";              // Baudrate init

            if (BackupData.DataBits > 0) cmbSettingDataBits.Text = BackupData.DataBits.ToString();
            else cmbSettingDataBits.Text = "8";                 // Data Bits init

            if (BackupData.Parity != Parity.None) cmbSettingParity.Text = BackupData.Parity.ToString();
            else cmbSettingParity.Text = "None";                // Parity bits init

            if (BackupData.StopBits != StopBits.None) cmbSettingStopBit.Text = BackupData.StopBits.ToString();
            else cmbSettingStopBit.Text = "One";                // Stop bit init

            if (BackupData.debugModeEnable == true) chbDbgModeEnable.Checked = true;
            else chbDbgModeEnable.Checked = false;
        }                                                       //

        /*
        Function : btnSettingOK_Click
        Detail   : Configuration confirm setting
        Input    : object sender, EventArgs e
        Output   : None
        History  : 2018-11-10 First written by S.Pairot
        */
        private void btnSettingOK_Click(object sender, EventArgs e)
        {
            Setting.ComPortName = Convert.ToString(cmbSettingComPort.Text);                    // Port name configuration 
            Setting.Baudrate = Convert.ToInt32(cmbSettingBaudrate.Text);                       // Baudrate configuration
            Setting.DataBits = Convert.ToInt16(cmbSettingDataBits.Text);                       // Data bit configuration
            Setting.Parity = (Parity)Enum.Parse(typeof(Parity), cmbSettingParity.Text);        // Parity configuration
            Setting.StopBits = (StopBits)Enum.Parse(typeof(StopBits), cmbSettingStopBit.Text); // Stop bit configuration
            Setting.debugModeEnable = chbDbgModeEnable.Checked;                                           // Debug mode configuration
            this.Close();
        }
        /*
        Function : btnSettingCancel_Click
        Detail   : Configuration cancel
        Input    : object sender, EventArgs e
        Output   : None
        History  : 2018-11-10 First written by S.Pairot
        */
        private void btnSettingCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /*
        Function : SETTING_SetComPortName
        Detail   : Configuration com port name
        Input    : None
        Output   : None
        History  : 2018-11-10 First written by S.Pairot
        */
        public void SETTING_SetComPortName()
        {
            /*Serial Comport configuration*/
            int PortIndex = -1;
            string ComPortName = null;
            string[] ArrayComPortsNames = null;

            ArrayComPortsNames = System.IO.Ports.SerialPort.GetPortNames();

            try
            {
                do
                {
                    PortIndex += 1;
                    cmbSettingComPort.Items.Add(ArrayComPortsNames[PortIndex]);  // comboBox add found items
                }
                while (!((ArrayComPortsNames[PortIndex] == ComPortName)
                || (PortIndex == ArrayComPortsNames.GetUpperBound(0))));
                Array.Sort(ArrayComPortsNames);

                /*want to get first out*/
                if (PortIndex == ArrayComPortsNames.GetUpperBound(0))
                {
                    ComPortName = ArrayComPortsNames[0];
                }
                
                if (BackupData.ComPortName != null)                      // comport last selected?
                {                                                        // 
                    cmbSettingComPort.Text = BackupData.ComPortName;     // display last comport select in comboBox
                }                                                        //
                else {                                                   //
                    cmbSettingComPort.Text = ArrayComPortsNames[0];      // First item display
                }

            }
            catch (Exception) { };
        }

        /*
        Function : btnSettingFindComPort_Click
        Detail   : Re-scan com port name
        Input    : object sender, EventArgs e
        Output   : None
        History  : 2018-11-10 First written by S.Pairot
        */
        private void btnSettingFindComPort_Click(object sender, EventArgs e)
        {
            cmbSettingComPort.Items.Clear();                  // Clear comport name last store
            SETTING_SetComPortName();                         // Call main form for re-scan com port change
        }
    }
}
/*----------------------------------EOF-----------------------------------*/
