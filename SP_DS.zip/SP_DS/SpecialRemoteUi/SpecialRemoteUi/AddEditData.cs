﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SpecialRemoteUi
{
    public partial class AddEditData : Form
    {
        public ManualEdit ManualEditInfo { get; set; }  // global object class

        public AddEditData()
        {
            InitializeComponent();
        }

        private void AddEditData_Load(object sender, EventArgs e)
        {
            using (FormMain frm = new FormMain())
            {
                frm.AddDataGridviewColumnHeader();
            }
            // Init data
            if (ManualEditInfo != null)
            {                                                        // Exiting data?
                txtID.Text = ManualEditInfo.ID;                      // Add ID to Textbox
                cmbType.Text = ManualEditInfo.Type;                  // Add Type to Textbox
                txtE2Address.Text = ManualEditInfo.E2Address;        // Add E2 Address to Textbox
                txtE2AddressInv.Text = ManualEditInfo.E2AddressInv;  // Add E2 Address inverse to Textbox
                txtE2Data.Text = ManualEditInfo.E2Data;              // Add E2 Data to Textbox
                txtE2DataInv.Text = ManualEditInfo.E2DataInv;        // Add E2 Data inverse to Textbox
                txtBaseE2Data.Text = ManualEditInfo.E2BaseData;      // Add Base E2 Data to Textbox
                txtBaseE2DataInv.Text = ManualEditInfo.E2BaseDataInv;// Add Base E2 Base Data inverse to Textbox
            }
            else
            {
                cmbType.Text = "FCU";                                // Display FCU
                txtID.Focus();                                       // Set cursor at ID box
            }
        }

        private void btnAddEditOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtID.Text) ||                  // Confirm all data was filled
                string.IsNullOrEmpty(cmbType.Text) ||
                string.IsNullOrEmpty(txtE2Address.Text) ||
                string.IsNullOrEmpty(txtE2AddressInv.Text) ||
                string.IsNullOrEmpty(txtE2Data.Text) ||
                string.IsNullOrEmpty(txtE2DataInv.Text) ||
                string.IsNullOrEmpty(txtBaseE2Data.Text) ||
                string.IsNullOrEmpty(txtBaseE2DataInv.Text))
            {
                if (DialogResult.OK == MessageBox.Show("Please enter data!!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation))
                {
                    this.DialogResult = DialogResult.None;           // If no fill data Keep form open
                }
            }
            else
            {
                ManualEditInfo.ID = txtID.Text;                      // Copy data from text box to global class
                ManualEditInfo.Type = cmbType.Text;
                ManualEditInfo.E2Address = txtE2Address.Text;
                ManualEditInfo.E2AddressInv = txtE2AddressInv.Text;
                ManualEditInfo.E2Data = txtE2Data.Text;
                ManualEditInfo.E2DataInv = txtE2DataInv.Text;
                ManualEditInfo.E2BaseData = txtBaseE2Data.Text;
                ManualEditInfo.E2BaseDataInv = txtBaseE2DataInv.Text;
            }
        }

        private void btnAddEditCancel_Click(object sender, EventArgs e)
        {
            this.Close();  // form close
        }

        // Check string input is hex data
        public bool IsHexValue(string strInput)
        {
            //create Regular Expression Match pattern object
            Regex myRegex = new Regex("^[a-fA-F0-9]+$");
            //boolean variable to hold the status
            bool isValid = false;
            if (string.IsNullOrEmpty(strInput))
            {
                isValid = false;
            }
            else
            {
                isValid = myRegex.IsMatch(strInput);
            }
            //return the results
            return isValid;
        }

        private void txtE2Address_Leave(object sender, EventArgs e)
        {
            ConvertData cvdat = new ConvertData();  // create new sub class object
            int L_data;
            if (IsHexValue(txtE2Address.Text))      // is hex value and no empty
            {
                byte[] L_byte = cvdat.HexToByte(txtE2Address.Text);                 // Convert hex data to byte array[]
                L_data = ~L_byte[0];                                                // Inverse data
                try
                {
                    txtE2AddressInv.Text = cvdat.TakeLast(L_data.ToString("X"), 2);  // Convert data to HEX and get last 2 digits
                    txtE2Address.Text = txtE2Address.Text.PadLeft(2, '0');           // Alway show 2 digit, If 1 digit add 0 at the front (1-->01)
                    txtE2Address.Text = txtE2Address.Text.ToUpper();                 // Convert to Upper case
                }
                catch (Exception) { }
            }
            else
            {
                txtE2AddressInv.Text = "";
            }
        }

        private void txtE2Data_Leave(object sender, EventArgs e)
        {
            ConvertData cvdat = new ConvertData();  // create new sub class object
            int L_data;
            if (IsHexValue(txtE2Data.Text))      // is hex value and no empty
            {
                byte[] L_byte = cvdat.HexToByte(txtE2Data.Text);
                L_data = ~L_byte[0];
                try
                {
                    txtE2DataInv.Text = cvdat.TakeLast(L_data.ToString("X"), 2);
                    txtE2Data.Text = txtE2Data.Text.PadLeft(2, '0');
                    txtE2Data.Text = txtE2Data.Text.ToUpper();
                }
                catch (Exception) { }
            }
            else
            {
                txtE2DataInv.Text = "";
            }
        }

        private void txtBaseData_Leave(object sender, EventArgs e)
        {
            ConvertData cvdat = new ConvertData();  // create new sub class object
            int L_data;
            if (IsHexValue(txtBaseE2Data.Text))      // is hex value and no empty
            {
                byte[] L_byte = cvdat.HexToByte(txtBaseE2Data.Text);
                L_data = ~L_byte[0];
                try
                {
                    txtBaseE2DataInv.Text = cvdat.TakeLast(L_data.ToString("X"), 2);
                    txtBaseE2Data.Text = txtBaseE2Data.Text.PadLeft(2, '0');
                    txtBaseE2Data.Text = txtBaseE2Data.Text.ToUpper();
                }
                catch (Exception) { }
            }
            else
            {
                txtBaseE2DataInv.Text = "";
            }
        }
    }
}
