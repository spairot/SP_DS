﻿namespace SpecialRemoteUi
{
    partial class SettingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SettingPanel = new System.Windows.Forms.Panel();
            this.btnSettingFindComPort = new System.Windows.Forms.Button();
            this.btnSettingCancel = new System.Windows.Forms.Button();
            this.btnSettingOK = new System.Windows.Forms.Button();
            this.tabSetting = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.grbSerialSetting = new System.Windows.Forms.GroupBox();
            this.cmbSettingStopBit = new System.Windows.Forms.ComboBox();
            this.cmbSettingParity = new System.Windows.Forms.ComboBox();
            this.cmbSettingDataBits = new System.Windows.Forms.ComboBox();
            this.cmbSettingBaudrate = new System.Windows.Forms.ComboBox();
            this.cmbSettingComPort = new System.Windows.Forms.ComboBox();
            this.lblSeetingStopBit = new System.Windows.Forms.Label();
            this.lblSettingPairity = new System.Windows.Forms.Label();
            this.lblDataBits = new System.Windows.Forms.Label();
            this.lblComPort = new System.Windows.Forms.Label();
            this.lblBaudrate = new System.Windows.Forms.Label();
            this.tabPageDbgSet = new System.Windows.Forms.TabPage();
            this.chbDbgModeEnable = new System.Windows.Forms.CheckBox();
            this.lblDebugMode = new System.Windows.Forms.Label();
            this.SettingPanel.SuspendLayout();
            this.tabSetting.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.grbSerialSetting.SuspendLayout();
            this.tabPageDbgSet.SuspendLayout();
            this.SuspendLayout();
            // 
            // SettingPanel
            // 
            this.SettingPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SettingPanel.Controls.Add(this.btnSettingFindComPort);
            this.SettingPanel.Controls.Add(this.btnSettingCancel);
            this.SettingPanel.Controls.Add(this.btnSettingOK);
            this.SettingPanel.Controls.Add(this.tabSetting);
            this.SettingPanel.Location = new System.Drawing.Point(11, 11);
            this.SettingPanel.Name = "SettingPanel";
            this.SettingPanel.Size = new System.Drawing.Size(311, 241);
            this.SettingPanel.TabIndex = 0;
            // 
            // btnSettingFindComPort
            // 
            this.btnSettingFindComPort.Location = new System.Drawing.Point(186, 207);
            this.btnSettingFindComPort.Name = "btnSettingFindComPort";
            this.btnSettingFindComPort.Size = new System.Drawing.Size(84, 25);
            this.btnSettingFindComPort.TabIndex = 5;
            this.btnSettingFindComPort.Text = "Find ComPort";
            this.btnSettingFindComPort.UseVisualStyleBackColor = true;
            this.btnSettingFindComPort.Click += new System.EventHandler(this.btnSettingFindComPort_Click);
            // 
            // btnSettingCancel
            // 
            this.btnSettingCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnSettingCancel.Location = new System.Drawing.Point(107, 207);
            this.btnSettingCancel.Name = "btnSettingCancel";
            this.btnSettingCancel.Size = new System.Drawing.Size(73, 25);
            this.btnSettingCancel.TabIndex = 4;
            this.btnSettingCancel.Text = "&Cancel";
            this.btnSettingCancel.UseVisualStyleBackColor = true;
            this.btnSettingCancel.Click += new System.EventHandler(this.btnSettingCancel_Click);
            // 
            // btnSettingOK
            // 
            this.btnSettingOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSettingOK.Location = new System.Drawing.Point(28, 207);
            this.btnSettingOK.Name = "btnSettingOK";
            this.btnSettingOK.Size = new System.Drawing.Size(73, 25);
            this.btnSettingOK.TabIndex = 3;
            this.btnSettingOK.Text = "&OK";
            this.btnSettingOK.UseVisualStyleBackColor = true;
            this.btnSettingOK.Click += new System.EventHandler(this.btnSettingOK_Click);
            // 
            // tabSetting
            // 
            this.tabSetting.Controls.Add(this.tabPage1);
            this.tabSetting.Controls.Add(this.tabPageDbgSet);
            this.tabSetting.Location = new System.Drawing.Point(3, 5);
            this.tabSetting.Name = "tabSetting";
            this.tabSetting.SelectedIndex = 0;
            this.tabSetting.Size = new System.Drawing.Size(303, 200);
            this.tabSetting.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.grbSerialSetting);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(295, 174);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Serial Port";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // grbSerialSetting
            // 
            this.grbSerialSetting.Controls.Add(this.cmbSettingStopBit);
            this.grbSerialSetting.Controls.Add(this.cmbSettingParity);
            this.grbSerialSetting.Controls.Add(this.cmbSettingDataBits);
            this.grbSerialSetting.Controls.Add(this.cmbSettingBaudrate);
            this.grbSerialSetting.Controls.Add(this.cmbSettingComPort);
            this.grbSerialSetting.Controls.Add(this.lblSeetingStopBit);
            this.grbSerialSetting.Controls.Add(this.lblSettingPairity);
            this.grbSerialSetting.Controls.Add(this.lblDataBits);
            this.grbSerialSetting.Controls.Add(this.lblComPort);
            this.grbSerialSetting.Controls.Add(this.lblBaudrate);
            this.grbSerialSetting.Location = new System.Drawing.Point(6, 3);
            this.grbSerialSetting.Name = "grbSerialSetting";
            this.grbSerialSetting.Size = new System.Drawing.Size(283, 165);
            this.grbSerialSetting.TabIndex = 2;
            this.grbSerialSetting.TabStop = false;
            // 
            // cmbSettingStopBit
            // 
            this.cmbSettingStopBit.FormattingEnabled = true;
            this.cmbSettingStopBit.Items.AddRange(new object[] {
            "None",
            "One",
            "OnePointFive",
            "Two"});
            this.cmbSettingStopBit.Location = new System.Drawing.Point(81, 126);
            this.cmbSettingStopBit.Name = "cmbSettingStopBit";
            this.cmbSettingStopBit.Size = new System.Drawing.Size(91, 21);
            this.cmbSettingStopBit.TabIndex = 9;
            // 
            // cmbSettingParity
            // 
            this.cmbSettingParity.FormattingEnabled = true;
            this.cmbSettingParity.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even"});
            this.cmbSettingParity.Location = new System.Drawing.Point(81, 99);
            this.cmbSettingParity.Name = "cmbSettingParity";
            this.cmbSettingParity.Size = new System.Drawing.Size(91, 21);
            this.cmbSettingParity.TabIndex = 8;
            // 
            // cmbSettingDataBits
            // 
            this.cmbSettingDataBits.FormattingEnabled = true;
            this.cmbSettingDataBits.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
            this.cmbSettingDataBits.Location = new System.Drawing.Point(81, 72);
            this.cmbSettingDataBits.Name = "cmbSettingDataBits";
            this.cmbSettingDataBits.Size = new System.Drawing.Size(91, 21);
            this.cmbSettingDataBits.TabIndex = 7;
            // 
            // cmbSettingBaudrate
            // 
            this.cmbSettingBaudrate.FormattingEnabled = true;
            this.cmbSettingBaudrate.Items.AddRange(new object[] {
            "300",
            "600",
            "1200",
            "2400",
            "4800",
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200",
            "230400",
            "460800",
            "921600"});
            this.cmbSettingBaudrate.Location = new System.Drawing.Point(81, 45);
            this.cmbSettingBaudrate.Name = "cmbSettingBaudrate";
            this.cmbSettingBaudrate.Size = new System.Drawing.Size(91, 21);
            this.cmbSettingBaudrate.TabIndex = 6;
            // 
            // cmbSettingComPort
            // 
            this.cmbSettingComPort.FormattingEnabled = true;
            this.cmbSettingComPort.Location = new System.Drawing.Point(81, 18);
            this.cmbSettingComPort.Name = "cmbSettingComPort";
            this.cmbSettingComPort.Size = new System.Drawing.Size(91, 21);
            this.cmbSettingComPort.TabIndex = 5;
            // 
            // lblSeetingStopBit
            // 
            this.lblSeetingStopBit.AutoSize = true;
            this.lblSeetingStopBit.Location = new System.Drawing.Point(12, 130);
            this.lblSeetingStopBit.Name = "lblSeetingStopBit";
            this.lblSeetingStopBit.Size = new System.Drawing.Size(55, 13);
            this.lblSeetingStopBit.TabIndex = 4;
            this.lblSeetingStopBit.Text = "Stop Bits :";
            // 
            // lblSettingPairity
            // 
            this.lblSettingPairity.AutoSize = true;
            this.lblSettingPairity.Location = new System.Drawing.Point(12, 104);
            this.lblSettingPairity.Name = "lblSettingPairity";
            this.lblSettingPairity.Size = new System.Drawing.Size(39, 13);
            this.lblSettingPairity.TabIndex = 3;
            this.lblSettingPairity.Text = "Parity :";
            // 
            // lblDataBits
            // 
            this.lblDataBits.AutoSize = true;
            this.lblDataBits.Location = new System.Drawing.Point(12, 76);
            this.lblDataBits.Name = "lblDataBits";
            this.lblDataBits.Size = new System.Drawing.Size(56, 13);
            this.lblDataBits.TabIndex = 2;
            this.lblDataBits.Text = "Data Bits :";
            // 
            // lblComPort
            // 
            this.lblComPort.AutoSize = true;
            this.lblComPort.Location = new System.Drawing.Point(12, 22);
            this.lblComPort.Name = "lblComPort";
            this.lblComPort.Size = new System.Drawing.Size(53, 13);
            this.lblComPort.TabIndex = 0;
            this.lblComPort.Text = "Com Port:";
            // 
            // lblBaudrate
            // 
            this.lblBaudrate.AutoSize = true;
            this.lblBaudrate.Location = new System.Drawing.Point(12, 49);
            this.lblBaudrate.Name = "lblBaudrate";
            this.lblBaudrate.Size = new System.Drawing.Size(56, 13);
            this.lblBaudrate.TabIndex = 1;
            this.lblBaudrate.Text = "Baudrate :";
            // 
            // tabPageDbgSet
            // 
            this.tabPageDbgSet.Controls.Add(this.lblDebugMode);
            this.tabPageDbgSet.Controls.Add(this.chbDbgModeEnable);
            this.tabPageDbgSet.Location = new System.Drawing.Point(4, 22);
            this.tabPageDbgSet.Name = "tabPageDbgSet";
            this.tabPageDbgSet.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDbgSet.Size = new System.Drawing.Size(295, 174);
            this.tabPageDbgSet.TabIndex = 1;
            this.tabPageDbgSet.Text = "Debug Setting";
            this.tabPageDbgSet.UseVisualStyleBackColor = true;
            // 
            // chbDbgModeEnable
            // 
            this.chbDbgModeEnable.AutoSize = true;
            this.chbDbgModeEnable.Location = new System.Drawing.Point(96, 15);
            this.chbDbgModeEnable.Name = "chbDbgModeEnable";
            this.chbDbgModeEnable.Size = new System.Drawing.Size(65, 17);
            this.chbDbgModeEnable.TabIndex = 0;
            this.chbDbgModeEnable.Text = "Enabled";
            this.chbDbgModeEnable.UseVisualStyleBackColor = true;
            // 
            // lblDebugMode
            // 
            this.lblDebugMode.AutoSize = true;
            this.lblDebugMode.Location = new System.Drawing.Point(18, 16);
            this.lblDebugMode.Name = "lblDebugMode";
            this.lblDebugMode.Size = new System.Drawing.Size(72, 13);
            this.lblDebugMode.TabIndex = 1;
            this.lblDebugMode.Text = "Debug Mode:";
            // 
            // SettingForm
            // 
            this.AcceptButton = this.btnSettingOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 259);
            this.Controls.Add(this.SettingPanel);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SettingForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Setting";
            this.Load += new System.EventHandler(this.SettingForm_Load);
            this.SettingPanel.ResumeLayout(false);
            this.tabSetting.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.grbSerialSetting.ResumeLayout(false);
            this.grbSerialSetting.PerformLayout();
            this.tabPageDbgSet.ResumeLayout(false);
            this.tabPageDbgSet.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel SettingPanel;
        private System.Windows.Forms.Label lblBaudrate;
        private System.Windows.Forms.Label lblComPort;
        private System.Windows.Forms.GroupBox grbSerialSetting;
        private System.Windows.Forms.TabControl tabSetting;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnSettingCancel;
        private System.Windows.Forms.Button btnSettingOK;
        private System.Windows.Forms.Button btnSettingFindComPort;
        private System.Windows.Forms.Label lblSeetingStopBit;
        private System.Windows.Forms.Label lblSettingPairity;
        private System.Windows.Forms.Label lblDataBits;
        private System.Windows.Forms.ComboBox cmbSettingBaudrate;
        private System.Windows.Forms.ComboBox cmbSettingComPort;
        private System.Windows.Forms.ComboBox cmbSettingDataBits;
        private System.Windows.Forms.ComboBox cmbSettingStopBit;
        private System.Windows.Forms.ComboBox cmbSettingParity;
        private System.Windows.Forms.TabPage tabPageDbgSet;
        private System.Windows.Forms.Label lblDebugMode;
        private System.Windows.Forms.CheckBox chbDbgModeEnable;
    }
}