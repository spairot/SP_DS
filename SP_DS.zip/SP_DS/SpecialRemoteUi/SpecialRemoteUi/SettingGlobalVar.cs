﻿using System;
using System.IO.Ports;  /*Serial port*/

namespace SpecialRemoteUi
{
    public class SettingData
    {
        public string ComPortName   { get; set; }
        public Int32 Baudrate       { get; set; }
        public Int16 DataBits       { get; set; }
        public Parity Parity        { get; set; }
        public StopBits StopBits    { get; set; }
        public bool debugModeEnable { get; set; }
    }


    /*Back up data class*/
    public class BackupData
    {
        public static string ComPortName  { get; set; }  // satatic var <ComPortName
        public static Int32 Baudrate      { get; set; }  // satatic var <Baudrate
        public static Int16 DataBits      { get; set; }  // satatic var <DataBits
        public static Parity Parity       { get; set; }  // satatic var <Parity
        public static StopBits StopBits   { get; set; }  // satatic var <StopBits
        public static bool debugModeEnable{ get; set; }  // satatic var <Debug enabled
    }
}
