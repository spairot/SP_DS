﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace SpecialRemoteUi
{
    public partial class ProgressForm : Form
    {
        public ProgressForm prog { get; set; }
        public DataParameter param = new DataParameter();

        public ProgressForm()
        {
            InitializeComponent();
        }

        private void ProgressForm_Load(object sender, EventArgs e)
        {
            if (!backgroundWorker.IsBusy)
            {
                backgroundWorker.RunWorkerAsync(param);
            }
        }

        public class DataParameter {
            public int Process;
            public string Message;
        }

        public bool PRO_bgwIsBusy()
        {
            return (backgroundWorker.IsBusy);
        }

        public void PRO_bgwRun()
        {
            backgroundWorker.RunWorkerAsync(param);
        }

        private void backgroundWorker_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            string msg = ((DataParameter)e.Argument).Message;
            int process = ((DataParameter)e.Argument).Process;
            int index = 1;

            try
            {
                for (int i = 0; i < process; i++)
                {
                    if (!backgroundWorker.CancellationPending)
                    {
                        backgroundWorker.ReportProgress(index++*100/process,string.Format(msg+"{0}%",i));
                        Thread.Sleep(10);
                    }
                }
            }
            catch (Exception)
            {
                backgroundWorker.CancelAsync();
            };
        }

        private void backgroundWorker_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            progressBar.Value = e.ProgressPercentage;
            lblPercentage.Text = string.Format(param.Message+"{0}%", e.ProgressPercentage);
            progressBar.Update();
        }

        private void backgroundWorker_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            this.Close();
        }

        private void ProgressForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (backgroundWorker.IsBusy)
                backgroundWorker.CancelAsync();
        }
    }
}
