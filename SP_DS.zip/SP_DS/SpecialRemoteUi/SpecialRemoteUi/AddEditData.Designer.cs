﻿namespace SpecialRemoteUi
{
    partial class AddEditData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtBaseE2DataInv = new System.Windows.Forms.TextBox();
            this.txtBaseE2Data = new System.Windows.Forms.TextBox();
            this.lblBaseData = new System.Windows.Forms.Label();
            this.btnAddEditCancel = new System.Windows.Forms.Button();
            this.btnAddEditOK = new System.Windows.Forms.Button();
            this.cmbType = new System.Windows.Forms.ComboBox();
            this.txtE2DataInv = new System.Windows.Forms.TextBox();
            this.txtE2Data = new System.Windows.Forms.TextBox();
            this.lblE2Data = new System.Windows.Forms.Label();
            this.txtE2AddressInv = new System.Windows.Forms.TextBox();
            this.txtE2Address = new System.Windows.Forms.TextBox();
            this.lblE2Address = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.lblType = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtBaseE2DataInv);
            this.panel1.Controls.Add(this.txtBaseE2Data);
            this.panel1.Controls.Add(this.lblBaseData);
            this.panel1.Controls.Add(this.btnAddEditCancel);
            this.panel1.Controls.Add(this.btnAddEditOK);
            this.panel1.Controls.Add(this.cmbType);
            this.panel1.Controls.Add(this.txtE2DataInv);
            this.panel1.Controls.Add(this.txtE2Data);
            this.panel1.Controls.Add(this.lblE2Data);
            this.panel1.Controls.Add(this.txtE2AddressInv);
            this.panel1.Controls.Add(this.txtE2Address);
            this.panel1.Controls.Add(this.lblE2Address);
            this.panel1.Controls.Add(this.txtID);
            this.panel1.Controls.Add(this.lblType);
            this.panel1.Controls.Add(this.lblID);
            this.panel1.Location = new System.Drawing.Point(7, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(251, 210);
            this.panel1.TabIndex = 0;
            // 
            // txtBaseE2DataInv
            // 
            this.txtBaseE2DataInv.Location = new System.Drawing.Point(166, 120);
            this.txtBaseE2DataInv.Name = "txtBaseE2DataInv";
            this.txtBaseE2DataInv.ReadOnly = true;
            this.txtBaseE2DataInv.Size = new System.Drawing.Size(65, 20);
            this.txtBaseE2DataInv.TabIndex = 11;
            // 
            // txtBaseE2Data
            // 
            this.txtBaseE2Data.Location = new System.Drawing.Point(96, 120);
            this.txtBaseE2Data.MaxLength = 2;
            this.txtBaseE2Data.Name = "txtBaseE2Data";
            this.txtBaseE2Data.Size = new System.Drawing.Size(65, 20);
            this.txtBaseE2Data.TabIndex = 10;
            this.txtBaseE2Data.Leave += new System.EventHandler(this.txtBaseData_Leave);
            // 
            // lblBaseData
            // 
            this.lblBaseData.AutoSize = true;
            this.lblBaseData.Location = new System.Drawing.Point(19, 122);
            this.lblBaseData.Name = "lblBaseData";
            this.lblBaseData.Size = new System.Drawing.Size(60, 13);
            this.lblBaseData.TabIndex = 9;
            this.lblBaseData.Text = "Base Data:";
            // 
            // btnAddEditCancel
            // 
            this.btnAddEditCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAddEditCancel.Location = new System.Drawing.Point(31, 165);
            this.btnAddEditCancel.Name = "btnAddEditCancel";
            this.btnAddEditCancel.Size = new System.Drawing.Size(97, 30);
            this.btnAddEditCancel.TabIndex = 8;
            this.btnAddEditCancel.Text = "&Cancel";
            this.btnAddEditCancel.UseVisualStyleBackColor = true;
            this.btnAddEditCancel.Click += new System.EventHandler(this.btnAddEditCancel_Click);
            // 
            // btnAddEditOK
            // 
            this.btnAddEditOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAddEditOK.Location = new System.Drawing.Point(134, 165);
            this.btnAddEditOK.Name = "btnAddEditOK";
            this.btnAddEditOK.Size = new System.Drawing.Size(97, 30);
            this.btnAddEditOK.TabIndex = 7;
            this.btnAddEditOK.Text = "&OK";
            this.btnAddEditOK.UseVisualStyleBackColor = true;
            this.btnAddEditOK.Click += new System.EventHandler(this.btnAddEditOK_Click);
            // 
            // cmbType
            // 
            this.cmbType.FormattingEnabled = true;
            this.cmbType.Items.AddRange(new object[] {
            "FCU",
            "CDU"});
            this.cmbType.Location = new System.Drawing.Point(96, 37);
            this.cmbType.Name = "cmbType";
            this.cmbType.Size = new System.Drawing.Size(135, 21);
            this.cmbType.TabIndex = 2;
            // 
            // txtE2DataInv
            // 
            this.txtE2DataInv.Location = new System.Drawing.Point(166, 92);
            this.txtE2DataInv.Name = "txtE2DataInv";
            this.txtE2DataInv.ReadOnly = true;
            this.txtE2DataInv.Size = new System.Drawing.Size(65, 20);
            this.txtE2DataInv.TabIndex = 6;
            // 
            // txtE2Data
            // 
            this.txtE2Data.Location = new System.Drawing.Point(96, 92);
            this.txtE2Data.MaxLength = 2;
            this.txtE2Data.Name = "txtE2Data";
            this.txtE2Data.Size = new System.Drawing.Size(65, 20);
            this.txtE2Data.TabIndex = 5;
            this.txtE2Data.Leave += new System.EventHandler(this.txtE2Data_Leave);
            // 
            // lblE2Data
            // 
            this.lblE2Data.AutoSize = true;
            this.lblE2Data.Location = new System.Drawing.Point(19, 95);
            this.lblE2Data.Name = "lblE2Data";
            this.lblE2Data.Size = new System.Drawing.Size(58, 13);
            this.lblE2Data.TabIndex = 0;
            this.lblE2Data.Text = "New Data:";
            // 
            // txtE2AddressInv
            // 
            this.txtE2AddressInv.Location = new System.Drawing.Point(166, 64);
            this.txtE2AddressInv.Name = "txtE2AddressInv";
            this.txtE2AddressInv.ReadOnly = true;
            this.txtE2AddressInv.Size = new System.Drawing.Size(65, 20);
            this.txtE2AddressInv.TabIndex = 4;
            // 
            // txtE2Address
            // 
            this.txtE2Address.Location = new System.Drawing.Point(96, 64);
            this.txtE2Address.MaxLength = 2;
            this.txtE2Address.Name = "txtE2Address";
            this.txtE2Address.Size = new System.Drawing.Size(65, 20);
            this.txtE2Address.TabIndex = 3;
            this.txtE2Address.Leave += new System.EventHandler(this.txtE2Address_Leave);
            // 
            // lblE2Address
            // 
            this.lblE2Address.AutoSize = true;
            this.lblE2Address.Location = new System.Drawing.Point(19, 67);
            this.lblE2Address.Name = "lblE2Address";
            this.lblE2Address.Size = new System.Drawing.Size(48, 13);
            this.lblE2Address.TabIndex = 0;
            this.lblE2Address.Text = "Address:";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(96, 9);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(135, 20);
            this.txtID.TabIndex = 1;
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(19, 38);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(34, 13);
            this.lblType.TabIndex = 0;
            this.lblType.Text = "Type:";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(19, 12);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(21, 13);
            this.lblID.TabIndex = 0;
            this.lblID.Text = "ID:";
            // 
            // AddEditData
            // 
            this.AcceptButton = this.btnAddEditOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(267, 223);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "AddEditData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Add/Edit Data";
            this.Load += new System.EventHandler(this.AddEditData_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cmbType;
        private System.Windows.Forms.TextBox txtE2DataInv;
        private System.Windows.Forms.TextBox txtE2Data;
        private System.Windows.Forms.Label lblE2Data;
        private System.Windows.Forms.TextBox txtE2AddressInv;
        private System.Windows.Forms.TextBox txtE2Address;
        private System.Windows.Forms.Label lblE2Address;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Button btnAddEditCancel;
        private System.Windows.Forms.Button btnAddEditOK;
        private System.Windows.Forms.TextBox txtBaseE2DataInv;
        private System.Windows.Forms.TextBox txtBaseE2Data;
        private System.Windows.Forms.Label lblBaseData;
    }
}