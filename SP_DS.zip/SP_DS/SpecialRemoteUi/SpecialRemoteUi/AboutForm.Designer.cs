﻿namespace SpecialRemoteUi
{
    partial class AboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutForm));
            this.lblAbout = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbliCon = new System.Windows.Forms.Label();
            this.lblVer = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblAbout
            // 
            this.lblAbout.AutoSize = true;
            this.lblAbout.Location = new System.Drawing.Point(4, 6);
            this.lblAbout.Name = "lblAbout";
            this.lblAbout.Size = new System.Drawing.Size(286, 78);
            this.lblAbout.TabIndex = 1;
            this.lblAbout.Text = resources.GetString("lblAbout.Text");
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lbliCon);
            this.panel1.Controls.Add(this.lblVer);
            this.panel1.Controls.Add(this.lblAbout);
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(304, 290);
            this.panel1.TabIndex = 2;
            // 
            // lbliCon
            // 
            this.lbliCon.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lbliCon.Image = ((System.Drawing.Image)(resources.GetObject("lbliCon.Image")));
            this.lbliCon.Location = new System.Drawing.Point(77, 90);
            this.lbliCon.Name = "lbliCon";
            this.lbliCon.Size = new System.Drawing.Size(136, 159);
            this.lbliCon.TabIndex = 3;
            // 
            // lblVer
            // 
            this.lblVer.AutoSize = true;
            this.lblVer.Location = new System.Drawing.Point(85, 255);
            this.lblVer.Name = "lblVer";
            this.lblVer.Size = new System.Drawing.Size(121, 26);
            this.lblVer.TabIndex = 2;
            this.lblVer.Text = "Special Remote UI V1.0\r\n    by Pairot Sukhirun";
            // 
            // AboutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(315, 300);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "AboutForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "About";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblAbout;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblVer;
        private System.Windows.Forms.Label lbliCon;
    }
}