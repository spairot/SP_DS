﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecialRemoteUi
{
    public class ManualEdit
    {
        public string ID { get; set; }             // ID 
        public string Type { get; set; }           // A/C Type FCU/CDU
        public string E2Address { get; set; }      // EEPROM address
        public string E2AddressInv { get; set; }   // EEPROM address inverse
        public string E2Data { get; set; }         // EEPROM data
        public string E2DataInv { get; set; }      // EEPROM data inverse
        public string E2BaseData { get; set; }     // EEPROM base data 
        public string E2BaseDataInv { get; set; }  // EEPROM base data inverse
    }
}
