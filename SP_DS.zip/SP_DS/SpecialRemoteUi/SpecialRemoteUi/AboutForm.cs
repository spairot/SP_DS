﻿using System.Windows.Forms;

namespace SpecialRemoteUi
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();
        }

    }
}
